<?php
/**
* Plugin Name: Driveme common
* Plugin URI: jthemesstudio.com
* Description: A plugin to create custom post type, metabox,...
* Version:  1.0.2
* Author: jThemes Studio
* Author URI: jthemesstudio.com
* License:  GPL2
*/


include dirname( __FILE__ ) . '/custom-post-type/post_type.php';
include dirname( __FILE__ ) . '/custom-metaboxes/metabox-functions.php';
include dirname( __FILE__ ) . '/shortcodes.php';
include dirname( __FILE__ ) . '/widget/flickr1.php';
require_once dirname(__FILE__) . '/radium-one-click-demo-install-master/init.php';

add_shortcode('gallery', '__return_false');


//Transactions
add_action('init', 'driveme_transactions_init');

function driveme_transactions_init() {

    $args = array(
        'public' => false,
        'can_export' => true,
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'show_ui' => false
    );

    register_post_type('wp-driveme-trx', $args);

    register_post_status('archive', array(
        'label' => esc_html__('Archived', 'driveme'),
        'public' => true,
        '_builtin' => true, /* internal use only. */
        'label_count' => _n_noop('Archived <span class="count">(%s)</span>', 'Archived <span class="count">(%s)</span>', 'driveme'),
    ));
}


function driveme_transactions_run() {

    require_once( 'transactions.php' );
    driveme_transactions_render();
}

add_action('admin_menu', 'driveme_transactions_mi');

function driveme_transactions_mi() {

    $title = __('Transactions', 'driveme');

    add_submenu_page('edit.php?post_type=courses', $title, $title, 'manage_options', 'edit.php?post_type=wp-driveme-trx&page=transactions&post_status=publish');
    $page = add_submenu_page('edit.php?post_type=wp-driveme-trx', $title, $title, 'manage_options', 'transactions', 'driveme_transactions_run');
    add_action('admin_print_styles-' . $page, 'driveme_transactions_load_styles');
    add_action('admin_print_scripts-' . $page, 'driveme_transactions_load_scripts');
}

//Update courses slug
function add_courses_custom_rewrite_rule() {
    global $theme_option;
    if( post_type_exists('course') ) {
        $post_type = 'courses';
        $args = get_post_type_object($post_type);
        //var_dump($theme_option['courses_slug']);
        $args->rewrite = array('slug' => ($theme_option['courses_slug'] != '') ? $theme_option['courses_slug'] : 'courses');
        register_post_type($args->name, $args);
        flush_rewrite_rules();
    }
}

add_action('init', 'add_courses_custom_rewrite_rule', 90);

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if ( ! function_exists( 'remove_demo' ) ) {
    function remove_demo() {
        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
            remove_filter( 'plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2 );

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
        }
    }
}

// ajax=============================

function dm_ajax_payment_check()
{

    $nonse = check_ajax_referer( 'secure_payment', 'security' );

    if(!$nonse) {
        wp_die();
    }

    $result = array();
    $msg = array();

    $fields = array(
        'course' => 1,
        'email' => 1,
        'firstname' => 1,
        'lastname' => 1,
        'date' => 1,
        'message' => 0,
        'phone' => 0
    );

    $data = dm_sanitize_payment_data($_POST);

    $locale_req = __('Field is required', 'driveme');
    $locale_format = __('Invalid format', 'driveme');
    $locale_format_date = __('Invalid format. It should be [DD/MM/YY]', 'driveme');
    $date_past = __('Chosen date is in the past', 'driveme');

    foreach ($fields as $k => $v) {
        if ($v && $data[$k] == '')
            $msg[$k] = $locale_req;
    }

    if (!empty($data['email']) && !is_email($data['email']))
        $msg['email'] = $locale_format;

    if (!empty($data['date'])) {

        $y_digits = 2;
        if (preg_match('/[^0-9]([0-9]+)$/', $data['date'], $matches))
            $y_digits = strlen($matches[1]);
        $df = DateTime::createFromFormat('d#m#' . ($y_digits == 2 ? 'y' : 'Y'), $data['date']);
        if (!$df) {
            $msg['date'] = $locale_format_date;
        } else if ($df->getTimestamp() < time()) {
            $msg['date'] = $date_past . ': ' . date('Y-m-d', $df->getTimestamp());
        }
    }

    if (count($msg))
        $result['errors'] = $msg;
    else
        $result['ok'] = 1;

    while (ob_get_level())
        ob_end_clean();
    echo json_encode($result);
    exit();
}

add_action('wp_ajax_payment_check', 'dm_ajax_payment_check');
add_action('wp_ajax_nopriv_payment_check', 'dm_ajax_payment_check');


// payment stripe
function dm_ajax_payment_do_stripe() {

    global $theme_option;
    $nonse = check_ajax_referer( 'secure_payment', 'security' );

    if(!$nonse) {
        wp_die();
    }

    $result = array();
    $data = dm_sanitize_payment_data($_POST);

    require_once 'include/stripe/init.php';

    Stripe\Stripe::setApiKey(trim($theme_option['payment_cc_sk' . ($theme_option['payment_cc_testmode'] ? '_test' : '')]));
    $error = '';
    try {
        if (!isset($_POST['stripeToken'])) {
            throw new Exception("The Stripe Token was not generated correctly");
        }

        $customer = \Stripe\Customer::create(array(
                    'email' => $data['email'],
                    'card' => $_REQUEST['stripeToken']
        ));

        $charge = Stripe\Charge::create(array(
                    "amount" => round($data['amount'] * 100),
                    "currency" => $data['currency'],
                    'customer' => $customer->id,
                    "description" => $data['course'] . ' from ' . $data['email']
        ));
    } catch (Exception $e) {
        $error = $e->getMessage();
    }

    if (empty($error)) {

        $data['paid'] = $charge->paid;
        $data['amount'] = $charge->amount / 100;
        $data['currency'] = $charge->currency;
        $data['payment_raw'] = $charge->__toString();
        $data['testmode'] = !$charge->livemode;
        $data['trx'] = $charge->id;

        do_action('wp_driveme_on_transfer', 'Stripe: ' . $data['trx'], 'stripe', $data);

        $result['reload'] = add_query_arg('doaction', 'thank-you', $theme_option['courses_linkbooking']);
    } else
        $result['error'] = $error;

    while (ob_get_level())
        ob_end_clean();
    echo json_encode($result);
    exit();
}

add_action('wp_ajax_payment_do_stripe', 'dm_ajax_payment_do_stripe');
add_action('wp_ajax_nopriv_payment_do_stripe', 'dm_ajax_payment_do_stripe');


// offline
function dm_ajax_payment_do_offline() {

    $nonse = check_ajax_referer( 'secure_payment', 'security' );

    if(!$nonse) {
        wp_die();
    }

    global $theme_option;

    $result = array();

    $data = dm_sanitize_payment_data($_POST);

    do_action('wp_driveme_on_transfer', 'Offline request', 'offline', $data);

    $result['reload'] = add_query_arg('doaction', 'request', $theme_option['courses_linkbooking']);

    while (ob_get_level())
        ob_end_clean();
    echo json_encode($result);
    exit();
}

add_action('wp_ajax_payment_do_offline', 'dm_ajax_payment_do_offline');
add_action('wp_ajax_nopriv_payment_do_offline', 'dm_ajax_payment_do_offline');

// parser
function dm_ajax_payment_ipn() {

    global $wp;

    if (isset($_GET['action']) && $_GET['action'] == 'paypal_ipn_handler') {
        $wp->query_vars['driveme_paypal_ipn_loader'] = $_GET['action'];
    }

    if (empty($wp->query_vars['driveme_paypal_ipn_loader']))
        return;

    global $theme_option;

    include('include/paypal/ipnlistener.php');

    $post = &$_POST;

    $listener = new IpnListener();
    $listener->use_sandbox = $theme_option['payment_pp_sandbox'] ? true : false;
    $listener->use_curl = false;

    $verified = false;

    try {
        $verified = $listener->processIpn();
    } catch (Exception $e) {
        
    }

    $data = json_decode(urldecode($post['custom']), true);
    $data = dm_sanitize_payment_data($data);
    $data['payment_raw'] = $post;
    unset($data['payment_raw']['custom']);
    $data['payment_raw'] = json_encode($data['payment_raw'], JSON_PRETTY_PRINT);

    $data['amount'] = @$post['mc_gross'];
    $data['currency'] = @$post['mc_currency'];
    $data['paid'] = strtoupper(@$post['payment_status']) == "COMPLETED";
    $data['testmode'] = @$post['test_ipn'] ? true : false;
    $data['trx'] = $post['txn_id'];
    $date = strtotime(@$post['payment_date']);

    $return = 'cancel';
    if ($verified && $data['cid']) {

        $return = 'thank-you';
        do_action('wp_driveme_on_transfer', 'PayPal: ' . $data['trx'] . ' from ' . $post['payer_email'], 'paypal', $data, $data['testmode'], $date);
    }

    if (array_key_exists('doredirect', $_REQUEST)) {
        wp_redirect(add_query_arg('doaction', $return, $_REQUEST['doredirect']));
        exit;
    }

    die('1');
}

add_action('parse_request', 'dm_ajax_payment_ipn', 0);


// mail
function wp_driveme_trx_notify($post_id) {

    global $theme_option;

    $email = $theme_option['notification_email'];

    if (!$email)
        return false;

    $body = $theme_option['notification_body'];
    $subject = $theme_option['notification_subject'];

    $data = get_post_meta($post_id);
    $post = get_post($post_id);

    $repl = array('%stamp%' => $post->post_date);
    foreach ($data as $k => $v) {
        if (strpos($k, 'wp-driveme-trx-') === 0) {
            $repl['%' . str_replace('wp-driveme-trx-', '', $k) . '%'] = array_shift($v);
        }
    }

    $body = str_replace(array_keys($repl), array_values($repl), $body);
    $subject = str_replace(array_keys($repl), array_values($repl), $subject);

    return wp_mail($email, $subject, $body);
}

add_action('wp_driveme_on_after_transfer_save', 'wp_driveme_trx_notify');
