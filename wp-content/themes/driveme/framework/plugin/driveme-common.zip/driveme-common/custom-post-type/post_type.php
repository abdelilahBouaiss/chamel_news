<?php
add_action( 'init', 'register_driveme_Courses' );
function register_driveme_Courses() {
    
    $labels = array( 
        'name' => __( 'Courses', 'driveme' ),
        'singular_name' => __( 'Courses', 'driveme' ),
        'add_new' => __( 'Add New Courses', 'driveme' ),
        'add_new_item' => __( 'Add New Courses', 'driveme' ),
        'edit_item' => __( 'Edit Courses', 'driveme' ),
        'new_item' => __( 'New Courses', 'driveme' ),
        'view_item' => __( 'View Courses', 'driveme' ),
        'search_items' => __( 'Search Courses', 'driveme' ),
        'not_found' => __( 'No Courses found', 'driveme' ),
        'not_found_in_trash' => __( 'No Courses found in Trash', 'driveme' ),
        'parent_item_colon' => __( 'Parent Courses:', 'driveme' ),
        'menu_name' => __( 'Courses', 'driveme' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Courses',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
        'taxonomies' => array( 'Portfolio_category','categories','tags', 'location' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/images/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Courses', $args );
}
add_action( 'init', 'create_Categories_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Categories_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Categories', 'driveme' ),
    'singular_name' => __( 'Categories', 'driveme' ),
    'search_items' =>  __( 'Search Categories','driveme' ),
    'all_items' => __( 'All Categories','driveme' ),
    'parent_item' => __( 'Parent Categories','driveme' ),
    'parent_item_colon' => __( 'Parent Categories:','driveme' ),
    'edit_item' => __( 'Edit Categories','driveme' ), 
    'update_item' => __( 'Update Categories','driveme' ),
    'add_new_item' => __( 'Add New Categories','driveme' ),
    'new_item_name' => __( 'New Categories Name','driveme' ),
    'menu_name' => __( 'Categories','driveme' ),
  );     

// Now register the taxonomy

  register_taxonomy('categories',array('Courses'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'categories' ),
  ));

}
add_action( 'init', 'create_Tags_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Tags_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Tags', 'driveme' ),
    'singular_name' => __( 'Tags', 'driveme' ),
    'search_items' =>  __( 'Search Tags','driveme' ),
    'all_items' => __( 'All Tags','driveme' ),
    'parent_item' => __( 'Parent Tags','driveme' ),
    'parent_item_colon' => __( 'Parent Tags:','driveme' ),
    'edit_item' => __( 'Edit Tags','driveme' ), 
    'update_item' => __( 'Update Tags','driveme' ),
    'add_new_item' => __( 'Add New Tags','driveme' ),
    'new_item_name' => __( 'New Tags Name','driveme' ),
    'menu_name' => __( 'Tags','driveme' ),
  );     

// Now register the taxonomy

  register_taxonomy('tags',array('Courses'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'tags' ),
  ));

}

/*
*     location
* -----------------------------------------------------------------------------------------*/
//create a custom taxonomy name it Skillss for your posts
add_action( 'init', 'create_Location_hierarchical_taxonomy', 0 );

function create_Location_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Location', 'driveme' ),
    'singular_name' => __( 'Location', 'driveme' ),
    'search_items' =>  __( 'Search Location','driveme' ),
    'all_items' => __( 'All Location','driveme' ),
    'parent_item' => __( 'Parent Location','driveme' ),
    'parent_item_colon' => __( 'Parent Location:','driveme' ),
    'edit_item' => __( 'Edit Location','driveme' ), 
    'update_item' => __( 'Update location','driveme' ),
    'add_new_item' => __( 'Add New location','driveme' ),
    'new_item_name' => __( 'New location Name','driveme' ),
    'menu_name' => __( 'Location','driveme' ),
  );     

// Now register the taxonomy

  register_taxonomy('location',array('Courses'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'location' ),
  ));

}




//Gallery
add_action( 'init', 'register_driveme_Gallery' );
function register_driveme_Gallery() {
    
    $labels = array( 
        'name' => __( 'Gallery', 'driveme' ),
        'singular_name' => __( 'Gallery', 'driveme' ),
        'add_new' => __( 'Add New Gallery', 'driveme' ),
        'add_new_item' => __( 'Add New Gallery', 'driveme' ),
        'edit_item' => __( 'Edit Gallery', 'driveme' ),
        'new_item' => __( 'New Gallery', 'driveme' ),
        'view_item' => __( 'View Gallery', 'driveme' ),
        'search_items' => __( 'Search Gallery', 'driveme' ),
        'not_found' => __( 'No Gallery found', 'driveme' ),
        'not_found_in_trash' => __( 'No Gallery found in Trash', 'driveme' ),
        'parent_item_colon' => __( 'Parent Gallery:', 'driveme' ),
        'menu_name' => __( 'Gallery', 'driveme' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Gallery',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
        'taxonomies' => array( 'Portfolio_category','skills' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/images/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Gallery', $args );
}

add_action( 'init', 'create_Skills_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_Skills_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Skills', 'driveme' ),
    'singular_name' => __( 'Skills', 'driveme' ),
    'search_items' =>  __( 'Search Skills','driveme' ),
    'all_items' => __( 'All Skills','driveme' ),
    'parent_item' => __( 'Parent Skills','driveme' ),
    'parent_item_colon' => __( 'Parent Skills:','driveme' ),
    'edit_item' => __( 'Edit Skills','driveme' ), 
    'update_item' => __( 'Update Skills','driveme' ),
    'add_new_item' => __( 'Add New Skills','driveme' ),
    'new_item_name' => __( 'New Skills Name','driveme' ),
    'menu_name' => __( 'Skills','driveme' ),
  );     

// Now register the taxonomy

  register_taxonomy('skills',array('Gallery'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'skills' ),
  ));

}

//Inspectors
add_action( 'init', 'register_driveme_Inspectors' );
function register_driveme_Inspectors() {
    
    $labels = array( 
        'name' => __( 'Inspectors', 'driveme' ),
        'singular_name' => __( 'Inspectors', 'driveme' ),
        'add_new' => __( 'Add New Inspectors', 'driveme' ),
        'add_new_item' => __( 'Add New Inspectors', 'driveme' ),
        'edit_item' => __( 'Edit Inspectors', 'driveme' ),
        'new_item' => __( 'New Inspectors', 'driveme' ),
        'view_item' => __( 'View Inspectors', 'driveme' ),
        'search_items' => __( 'Search Inspectors', 'driveme' ),
        'not_found' => __( 'No Inspectors found', 'driveme' ),
        'not_found_in_trash' => __( 'No Inspectors found in Trash', 'driveme' ),
        'parent_item_colon' => __( 'Parent Inspectors:', 'driveme' ),
        'menu_name' => __( 'Inspectors', 'driveme' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Inspectors',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
        'taxonomies' => array( 'Portfolio_category','specialized' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/images/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Inspectors', $args );
}

add_action( 'init', 'create_Specialized_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_Specialized_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Specialized', 'driveme' ),
    'singular_name' => __( 'Specialized', 'driveme' ),
    'search_items' =>  __( 'Search Specialized','driveme' ),
    'all_items' => __( 'All Specialized','driveme' ),
    'parent_item' => __( 'Parent Specialized','driveme' ),
    'parent_item_colon' => __( 'Parent Specialized:','driveme' ),
    'edit_item' => __( 'Edit Specialized','driveme' ), 
    'update_item' => __( 'Update Specialized','driveme' ),
    'add_new_item' => __( 'Add New Specialized','driveme' ),
    'new_item_name' => __( 'New Specialized Name','driveme' ),
    'menu_name' => __( 'Specialized','driveme' ),
  );     

// Now register the taxonomy

  register_taxonomy('specialized',array('Inspectors'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'specialized' ),
  ));

}
?>