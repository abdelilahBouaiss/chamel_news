<?php

if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class driveme_transactions_table extends WP_List_Table {
    
    function __construct(){
        global $status, $page;
                
        parent::__construct( array(
            'singular'  => 'transaction',
            'plural'    => 'transactions',
            'ajax'      => true
        ) );
        
    }

    function column_default($item, $column_name){
        switch ($column_name){
            case 'email':
		        return $item->meta['email'];
            case 'method':
	            return $item->meta['processor'];
	        case 'date':
                return $item->meta['date'];
	        case 'amount':
                return $item->meta['processor'] == 'offline' || !$item->meta['paid'] ? __('Not paid', 'driveme') : ($item->meta['amount'].' '.$item->meta['currency'] .($item->meta['mode'] == 'TEST' ? '<br><b>'.$item->meta['mode'].'</b>' : ''));
	        case 'stamp':
		        if ( '0000-00-00 00:00:00' == $item->post_date ) {
                    $t_time = $h_time = __( 'Unpublished', 'driveme' );
                } else {
                    $t_time = get_the_time( __( 'Y/m/d g:i:s a', 'driveme' ), $item);
                    $m_time = $item->post_date;
                    $time = get_post_time( 'G', true, $item );

                    $time_diff = time() - $time;

                    if ( $time_diff > 0 && $time_diff < DAY_IN_SECONDS )
                        $h_time = sprintf( __( '%s ago', 'driveme' ), human_time_diff( $time ) );
                    else
                        $h_time = mysql2date( __( 'Y/m/d', 'driveme' ), $m_time );
                }
	            return $t_time.'<div>'. apply_filters( 'post_date_column_time', $h_time, $item, $column_name, '' ) . '</div>';
            default:
                return '';
        }
    }


	function column_title($item){

		$tag = 'small';

		$actions = array(
			'view' => sprintf('<a href="#" data-modal-id="trxpopup%s">View</a>', $item->ID)
		);
		if ($item->post_status == 'publish') {
			$actions['archive'] = sprintf( '<a href="?post_type=wp-driveme-trx&amp;page=%s&action=%s&amp;transaction[0]=%s&amp;_wp_http_referer=%s">Archive</a>', $_REQUEST['page'], 'archive', $item->ID, urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ) );
			$tag = 'b';
		}
		if ($item->post_status == 'archive') {
			$actions['archive'] = sprintf( '<a href="?post_type=wp-driveme-trx&amp;page=%s&action=%s&amp;transaction[0]=%s&amp;_wp_http_referer=%s">Delete</a>', $_REQUEST['page'], 'delete', $item->ID, urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) ) );
			$tag = 'b';
		}
		$popup = sprintf('
			<div class="dm-modal-box" id="trxpopup%1$s">
			  <header> <a class="dm-close dm-modal-close" href="#">×</a>
			    <h3>%2$s - %3$s</h3>
			  </header>
			  <div class="dm-modal-body">
			    <ul>
			      <li>Course: <b>%9$s</b></li>
			      <li>Date: <b>%10$s</b></li>
			      <li>&nbsp;</li>
			      <li>Name: <b>%4$s %5$s</b></li>
			      <li>Email: <b>%6$s</b></li>
			      <li>Phone: <b>%7$s</b></li>
			      <li>Message:<ul><li><b>%8$s</b></li></ul></li>
			    </ul>
			    <hr>
			    <ul>
			      <li>Mode: <b>%11$s</b></li>
			      <li>Paid: <b>%12$s</b></li>
			      <li>Processor: <b>%13$s</b></li>
			      <li>Amount: <b>%14$s %15$s</b></li>
			      <li>Transaction: <b>%16$s</b></li>
			      <li>Payment Raw: <textarea class="fullwidth">%17$s</textarea></li>
			    </ul>
			  </div>
			  <footer> <a class="dm-btn dm-modal-close" href="#">'.__('Close', 'driveme').'</a> </footer>
			</div>',
			$item->ID,
			$item->post_date,
			$item->post_title,
			$item->meta['firstname'],
			$item->meta['lastname'],
			$item->meta['email'],
			$item->meta['phone'],
			$item->meta['message'],
			$item->meta['course'],
			$item->meta['date'],
			$item->meta['mode'],
			$item->meta['paid'],
			$item->meta['processor'],
			$item->meta['amount'],
			$item->meta['currency'],
			$item->meta['transaction'],
			htmlspecialchars($item->meta['payment_raw'])
		);

		return sprintf('<a href="#" data-modal-id="trxpopup%s">%s</a>', $item->ID, "<$tag>".$item->meta['course']."</$tag>").$this->row_actions($actions).$popup;
    }
	function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],
            /*$2%s*/ $item->ID
        );
    }

    function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />',
            'title'     => __('Title', 'driveme'),
            'date'     => __('For Date', 'driveme'),
            'email'     => __('Email', 'driveme'),
            'method'    => __('Method', 'driveme'),
            'amount'    => __('Amount', 'driveme'),
            'stamp'     => __('When', 'driveme'),
        );
        return $columns;
    }

    function get_sortable_columns() {
        $sortable_columns = array(
            'title'     => 'title',
            'stamp'     => array('date', true),
        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        if($_GET['post_status']=='archive'){
			$actions = array(
				'delete'    => 'Delete'
			);
		}
		else{
			$actions = array(
				'archive'    => 'Archive'
			);
		}
        return $actions;
    }

    function process_bulk_action() {
        
        if( 'archive' === $this->current_action() ) {
			foreach ($_GET['transaction'] as $id) {
				$post = array();
		        $post['ID'] = $id;
		        $post['post_status'] = 'archive';
				wp_update_post( $post );
			}
	       
        }
		if( 'delete' === $this->current_action() ) {
			foreach ($_GET['transaction'] as $id) {
				$post = array();
		        $post['ID'] = $id;
		       // $post['post_status'] = 'archive';
				wp_delete_post( $id );
			}
	        wp_redirect(array_key_exists('_wp_http_referer', $_REQUEST) ? $_REQUEST['_wp_http_referer'] : 'edit.php?post_type=wp-driveme-trx&page='.$_REQUEST['page']);
	        exit;
        }
        
    }

	public function prepare_items() {
		global $wp_query, $per_page, $mode;

		$columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();

		$this->_column_headers = array($columns, $hidden, $sortable);

		$this->process_bulk_action();

		$avail_post_stati = wp_edit_posts_query();

		$total_items = $wp_query->found_posts;

		$post_type = $this->screen->post_type;
		$per_page = $this->get_items_per_page( 'edit_' . $post_type . '_per_page' );

		/** This filter is documented in wp-admin/includes/post.php */
 		$per_page = apply_filters( 'edit_posts_per_page', $per_page, $post_type );
		$total_pages = $wp_query->max_num_pages;

		$this->set_pagination_args( array(
			'total_items' => $total_items,
			'total_pages' => $total_pages,
			'per_page' => $per_page
		) );

		$this->items = $wp_query->posts;
		foreach ($this->items as $kk=>$vv) {
			$meta = array();
			foreach (get_post_meta($vv->ID) as $k=>$v) {
				if (strpos($k, 'wp-driveme-trx-') === 0) {
					$meta[str_replace('wp-driveme-trx-', '', $k)] = array_shift($v);
				}
			}
			$this->items[$kk]->meta = $meta;
		}
	}

	/**
	 * @global int $cat
	 * @param string $which
	 */
	protected function extra_tablenav( $which ) {
		global $cat;
		?><div class="alignleft actions"><?php
		if ( 'top' == $which && !is_singular() ) {

			$this->months_dropdown( $this->screen->post_type );

			do_action( 'restrict_manage_posts' );

			submit_button( __( 'Filter', 'driveme' ), 'button', 'filter_action', false, array( 'id' => 'post-query-submit' ) );
		}
		?></div><?php
	}

	protected function is_base_request() {
		if ( empty( $_GET ) ) {
			return true;
		} elseif ( 1 === count( $_GET ) && ! empty( $_GET['post_type'] ) ) {
			return $this->screen->post_type === $_GET['post_type'];
		}

		return false;
	}

	protected function get_views() {

		$status_links = array();
		$num_posts = wp_count_posts( 'wp-driveme-trx', 'readable' );
		$class = '';

		$total_posts = array_sum( (array) $num_posts );

		if ( empty( $class ) && $this->is_base_request() ) {
			$class =  ' class="current"';
		}

		$all_inner_html = sprintf(
			__( 'All <span class="count">(%s)</span>' .$total_posts, 'driveme'),
			number_format_i18n( $total_posts )
		);

		$status_links['all'] = "<a href='edit.php?post_type=wp-driveme-trx&amp;page=transactions'$class>" . $all_inner_html . '</a>';

		$avail_post_stati = get_available_post_statuses('wp-driveme-trx');

		foreach ( get_post_stati(array('show_in_admin_status_list' => true), 'objects') as $status ) {
			$class = '';

			$status_name = $status->name;

			if ( !in_array( $status_name, $avail_post_stati ) )
				continue;

			if ( empty( $num_posts->$status_name ) && $status_name != 'publish' )
				continue;

			if ( isset($_REQUEST['post_status']) && $status_name == $_REQUEST['post_status'] )
				$class = ' class="current"';

			$status_links[$status_name] = "<a href='edit.php?post_status=$status_name&amp;post_type=wp-driveme-trx&amp;page=transactions'$class>" . sprintf( translate_nooped_plural( $status->label_count, $num_posts->$status_name ), number_format_i18n( $num_posts->$status_name ) ) . '</a>';
		}

		return $status_links;
	}
}

function driveme_transactions_render(){
    
    $ListTable = new driveme_transactions_table();
	$ListTable->prepare_items();

    ?>
    <div class="wrap">
        
        <h2>Transactions</h2>
	    <?php $ListTable->views() ?>
        <form id="movies-filter" method="get">
	        <?php $ListTable->search_box( __('Search Transactions', 'driveme'), 'search-submit' ); ?>
            <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>" />
            <input type="hidden" name="post_type" value="<?php echo esc_attr( $_REQUEST['post_type'] ); ?>" />
            <?php $ListTable->display() ?>
        </form>
        
    </div>
    <?php
}