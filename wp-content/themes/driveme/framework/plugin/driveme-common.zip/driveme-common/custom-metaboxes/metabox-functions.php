<?php

/**

 * Include and setup custom metaboxes and fields.

 *

 * @category YourThemeOrPlugin

 * @package  Metaboxes

 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)

 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress

 */



add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );

/**

 * Define the metabox and field configurations.

 *

 * @param  array $meta_boxes

 * @return array

 */

function cmb_sample_metaboxes( array $meta_boxes ) {



	// Start with an underscore to hide fields from custom fields list

	$prefix = '_cmb_';

	

    $meta_boxes[] = array(

        'id'         => 'page_setting',

        'title'      => 'Page Setting',

        'pages'      => array('page'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name' => 'Page Sub Title',

                'desc' => 'Set Page Sub Title',

                'id'   => $prefix . 'page_sub_title',

                'type'    => 'text',

                ),           

            )

        );

		$meta_boxes[] = array(

        'id'         => 'preloader_setting',

        'title'      => 'Preloader Setting',

        'pages'      => array('page','post','courses','gallery','inspectors'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name' => 'Disable Preloader',

                'desc' => 'Disable Preloader',

                'id'   => $prefix . 'disable_preloader',
				

                    'type' => 'checkbox',

                ),           

            )

        );

	// Add other metaboxes as needed



    $meta_boxes[] = array(

        'id'         => 'post_setting',

        'title'      => 'Post Setting',

        'pages'      => array('post'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(              


            array(

                'name'    => __( 'Choose type of Sidebar.', 'cmb' ),

                'desc'    => __( 'Sidebar left Or Sidebar Right.', 'cmb' ),

                'id'      => $prefix . 'post_sidebar',

                'type'    => 'select',

                'options' => array(  

                    array('name' => __( 'SIdebar Right', 'cmb' ), 'value' => 'right',),

                    array('name' => __( 'Sidebar Left', 'cmb' ), 'value' => 'left',), 



                    ),

                ), 
            array(

                'name' => 'Subtitle:',

                'desc' => '',

                'id'   => $prefix . 'subtitle',

                'type' => 'text',

                'std'  => 'Lessons From just $20 Per Hour or 5 Lessons for $120 or 10 Hours For $180',

                ),     

            array(

                'name' => __( 'Link Video Youtube or Vimeo.', 'cmb' ),

                'desc' => __( 'EX: https://www.youtube.com/embed/dorZ3vag5PI Or https://player.vimeo.com/video/103694372', 'cmb' ),

                'id'   => $prefix . 'link_video',

                'default' => '',

                'type' => 'text'

                ), 

            

            )

        );

	// Add other metaboxes as needed



    $meta_boxes[] = array(

        'id'         => 'courses_setting',

        'title'      => 'Courses Setting',

        'pages'      => array('courses'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name'    => __( 'Choose type of Sidebar.', 'cmb' ),

                'desc'    => __( 'Sidebar left Or Sidebar Right.', 'cmb' ),

                'id'      => $prefix . 'courses_sidebar',

                'type'    => 'select',

                'options' => array(  

                    array('name' => __( 'SIdebar Right', 'cmb' ), 'value' => 'right',),

                    array('name' => __( 'Sidebar Left', 'cmb' ), 'value' => 'left',), 



                    ),

                ),      			

            array(

                'name' => 'Link Video For Courses',

                'desc' => 'Link Your Video Ex: https://player.vimeo.com/video/1330769',

                'id'   => $prefix . 'courses_video',

                'type'    => 'text',

                ),   

            array(

                'name' => 'Price Of Courses.',

                'desc' => '',

                'id'   => $prefix . 'courses_price',

                'type' => 'text_medium',

                'std'  => '',

                ),

            array(

                'name'    => __( 'Rating Star', 'cmb' ),

                'desc'    => __( 'Type Rating Star of Courses', 'cmb' ),

                'id'      => $prefix . 'courses_rate',

                'type'    => 'select',

                'options' => array(  

                    array('name' => __( '5 Star', 'cmb' ), 'value' => 'five',),

                    array('name' => __( '0 Star', 'cmb' ), 'value' => 'zero',),            

                    array('name' => __( '1 Star', 'cmb' ), 'value' => 'one',),

                    array('name' => __( '2 Star', 'cmb' ), 'value' => 'two',),

                    array('name' => __( '3 Star', 'cmb' ), 'value' => 'three',),

                    array('name' => __( '4 Star', 'cmb' ), 'value' => 'four',),



                    ),

                ),

            array(

                'name' => 'Name of City.',

                'desc' => '',

                'id'   => $prefix . 'courses_city',

                'type' => 'text',

                'std'  => 'Manhattan / NYC',

                ),

            array(

                'name' => 'Name of Courses',

                'desc' => '',

                'id'   => $prefix . 'courses_name',

                'type' => 'text',

                'std'  => 'Courses Name',

                ),

            array(

                'name' => 'Address Of Courses',

                'desc' => '',

                'id'   => $prefix . 'courses_address',

                'type' => 'text',

                'std'  => 'Courses Address',

                ),

            array(

                'name' => 'latitude of Address.',

                'desc' => 'Please search at here: http://www.latlong.net/',

                'id'   => $prefix . 'courses_lat',

                'type' => 'text',

                'std'  => '-37.8176419',

                ),

            array(

                'name' => 'longitude of Address.',

                'desc' => 'Please search at here: http://www.latlong.net/',

                'id'   => $prefix . 'courses_long',

                'type' => 'text',

                'std'  => '144.9554397',

                ),

         
            /*
            *    location group field
            * -----------------------------------------------------------------------------------------*/
            
            array(
                'id'          => $prefix .'location_map',
                'type'        => 'group',
                'options'     => array(
                    'group_title'   => __( 'Add Map Location', 'cmb2' ), // since version 1.1.4, {#} gets replaced by row number
                    'add_button'    => __( 'Add Another Map Location', 'cmb2' ),
                    'remove_button' => __( 'Remove Entry', 'cmb2' ),
                    'sortable'      => true, // beta
                ),
                // Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.
                'fields'      => array(
                    array(
                        'name' => 'Location - Address',
                        'id'   => 'location_details',
                        'type' => 'text',
                        ),

                    array(
                        'name' => 'Location - Icon (32x32)',
                        'id'   => 'location_logo',
                        'type' => 'file',
                        ),

                    
                    array(
                        'name' => 'Latitude',
                        'id'   => 'location_lat',
                        'type' => 'text',
                        ),
                    array(
                        'name' => 'Longitude',
                        'id'   => 'location_lan',
                        'type' => 'text',
                        ),
                    ),
                ),



            /*
            *    date group field
            * -----------------------------------------------------------------------------------------*/
            
            array(
                'id'          => $prefix .'mulitple_course_date',
                'type'        => 'group',
                'options'     => array(
                    'group_title'   => __( 'Add Course Date', 'cmb2' ), // since version 1.1.4, {#} gets replaced by row number
                    'add_button'    => __( 'Add Another Course Date', 'cmb2' ),
                    'remove_button' => __( 'Remove Date', 'cmb2' ),
                    'sortable'      => true, // beta
                ),
                // Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.
                'fields'      => array(
                    
                   array(
                    'name' => 'Course Start (Date)',
                    'desc' => '',
                    'id'   => $prefix . 'courses_date',
                    'type' => 'text_date_timestamp',
                    'timezone_meta_key' => $prefix . 'timezone',
                    'date_format' => 'm/d/Y',
                    ),


                   array(
                    'name' => 'Time zone',
                    'id'   => $prefix . 'timezone',
                    'type' => 'select_timezone',
                    ),

                   
                    ),
                ),


            array(
                'name' => 'Time of Courses',
                'desc' => '',
                'id'   => $prefix . 'courses_time',
                'type' => 'text',
                'std'  => '6:30 PM to 8:30 PM (EST)',
                ),

            array(
                'name' => 'Car Type of Courses',
                'desc' => '',
                'id'   => $prefix . 'courses_car',
                'type' => 'text',
                'std'  => 'Car Type A',
                ),

            array(

                'name' => 'Image timeline',
                'desc' => '',
                'id'   => $prefix . 'courses_timeline',
                'type' => 'file',

                ),

            array(

                'name' => 'Courses Icon',

                'desc' => 'courses icon. ex: fa-check-circle',

                'id'   => $prefix . 'courses_icon',

                'type' => 'text',

                'std'  => 'fa-check-circle',

                ),

            array(

                'name' => 'Courses description',

                'desc' => 'courses description show in home page',

                'id'   => $prefix . 'courses_desc',

                'type' => 'textarea',

                'std'  => '',

                ),

            array(

                'name' => 'Courses title price 1',

                'desc' => 'courses title price show in home page 1',

                'id'   => $prefix . 'courses_title1',

                'type' => 'text',

                'std'  => 'Personal Driving',

                ),

            array(

                'name' => 'Courses title price 2',

                'desc' => 'courses title price show in home page 2',

                'id'   => $prefix . 'courses_title2',

                'type' => 'text',

                'std'  => 'Sımple',

                ),

            )

);

	// Add other metaboxes as needed

$meta_boxes[] = array(

    'id'         => 'gallery_setting',

    'title'      => 'Gallery Setting',

        'pages'      => array('gallery'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(              

            array(

                'name' => 'Location of Gallery',

                'desc' => 'Location. EX: Istanbul',

                'id'   => $prefix . 'gallery_location',

                'type'    => 'text',

                ),  

            array(

                'name'    => __( 'Choose Style Width', 'cmb' ),

                'desc'    => __( 'Type Of width In Gallery Masonary Page.', 'cmb' ),

                'id'      => $prefix . 'gallery_masonary',

                'type'    => 'select',

                'options' => array(  

                    array('name' => __( '50%', 'cmb' ), 'value' => 'half',),

                    array('name' => __( '100%', 'cmb' ), 'value' => 'full',),    



                    ),

                ),

            )

        );

// Add other metaboxes as needed

$meta_boxes[] = array(

    'id'         => 'inspectors_setting',

    'title'      => 'Inspectors Setting',

        'pages'      => array('inspectors'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(              

            array(

                'name' => 'Link Your Facebook.',

                'desc' => 'Link. EX: https://www.facebook.com/',

                'id'   => $prefix . 'inspectors_fb',

                'type'    => 'text',

                ),  

            array(

                'name' => 'Link Your Twitter.',

                'desc' => 'Link. EX: https://www.twitter.com/',

                'id'   => $prefix . 'inspectors_tw',

                'type'    => 'text',

                ),

            array(

                'name' => 'Link Your Googleplus.',

                'desc' => 'Link. EX: https://www.google.com/',

                'id'   => $prefix . 'inspectors_gg',

                'type'    => 'text',

                ),

            array(

                'name' => 'Link Your Linkedin.',

                'desc' => 'Link. EX: https://www.linkedin.com/',

                'id'   => $prefix . 'inspectors_ld',

                'type'    => 'text',

                ),

            array(

                'name' => 'Link Your Instagram.',

                'desc' => 'Link. EX: https://www.instagram.com/',

                'id'   => $prefix . 'inspectors_it',

                'type'    => 'text',

                ),

            array(

                'name' => 'Class of Other Social.',

                'desc' => 'Class. EX: fa-pinterest. View at here: http://fortawesome.github.io/Font-Awesome/cheatsheet/',

                'id'   => $prefix . 'inspectors_icon',

                'type'    => 'text',

                ),

            array(

                'name' => 'Link Your Other Social.',

                'desc' => 'Link.',

                'id'   => $prefix . 'inspectors_social',

                'type'    => 'text',

                'std'  => '#',

                ),

            )

        );

    // Add other metaboxes as needed

$meta_boxes[] = array(

  'id'         => 'seo_fields',

  'title'      => 'WordPress SEO by VergaTheme',

		'pages'      => array( 'page', 'post','portfolio'), // Post type

		'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

		//'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

           array(

            'name' => 'Focus Keyword:',

            'desc' => 'SEO keywords (optional)',

            'id'   => $prefix . 'seo_keywords',

            'type' => 'text',

            ),

           array(

            'name' => 'SEO Title:',

            'desc' => 'Title display in search engines is limited to 70 chars.',

            'id'   => $prefix . 'seo_title',

            'type' => 'text',

            ),

           array(

            'name' => 'Meta Description:',

            'desc' => 'The meta description will be limited to 156 chars.',

            'id'   => $prefix . 'seo_description',

            'type' => 'textarea',

            ),

           )

        );

	// Add other metaboxes as needed



return $meta_boxes;

}



add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );

/**

 * Initialize the metabox class.

 */

function cmb_initialize_cmb_meta_boxes() {



	if ( ! class_exists( 'cmb_Meta_Box' ) )

		require_once 'init.php';



}

