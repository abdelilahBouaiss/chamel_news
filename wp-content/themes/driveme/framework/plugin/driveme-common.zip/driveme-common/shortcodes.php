<?php
$textdomain = 'sportcup';
global $pre_text;

$pre_text = 'VG ';
global $theme_option;



//sportcup
//Slider
add_shortcode('slider', 'slider_func');

function slider_func($atts, $content = null) {
    extract(shortcode_atts(array(
        'title' => 'New Slider',
        'desc' => 'New Desc',
        'photo' => '',
        'show_form' => 'Yes',
        'type_form' => '1',
        'style_form' => '1',
        'text1' => 'Book Lesson',
        'link1' => '#',
        'text2' => 'Courses Price',
        'link2' => '#',
        'which_form' => '',
        'contact_form7' => '',
        'title_search' => 'Find Driving Course',
        'title_button' => 'Find My Courses',
                    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($photo, '');
    global $theme_option;
    ?>  
    <?php
    if ($images != '') {
        ?>
        <?php if ($style_form == '1') { ?>
            <li> <img src="<?php echo esc_url($images[0]); ?>" alt="">
                <div class="container">
                    <div class="align-c text-slider">
                        <?php if ($title != '') { ?>
                            <h3><?php echo esc_attr($title); ?> <i class="fa fa-long-arrow-right"></i></h3>
                            <?php
                        } else {
                            
                        }
                        ?>
                        <?php if ($desc != '') { ?>
                            <p><?php echo esc_attr($desc); ?></p>
                            <?php
                        } else {
                            
                        }
                        ?>
                        <div class="row"> 
                            <?php if ($text1 != '') { ?>
                                <a class="btn" href="<?php echo esc_url($link1); ?>"><?php echo esc_attr($text1); ?></a> 
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($text2 != '') { ?>  
                                <a class="btn btn-1" href="<?php echo esc_url($link2); ?>"><?php echo esc_attr($text2); ?></a> </div>
                            <?php
                        } else {
                            
                        }
                        ?>
                    </div>
                </div>
            </li>
        <?php } else if ($style_form == '2') { ?>
            <li> <img src="<?php echo esc_url($images[0]); ?>" alt="">
                <div class="container">
                    <div class="text-slider">
                        <div class="col-sm-7 col-md-7">
                            <?php if ($title != '') { ?>
                                <h3><?php echo esc_attr($title); ?> <i class="fa fa-long-arrow-right"></i></h3>
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($desc != '') { ?>
                                <p><?php echo esc_attr($desc); ?></p>
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($text1 != '') { ?>
                                <a class="btn" href="<?php echo esc_url($link1); ?>"><?php echo esc_attr($text1); ?></a> 
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($text2 != '') { ?>  
                                <a class="btn btn-1" href="<?php echo esc_url($link2); ?>"><?php echo esc_attr($text2); ?></a> </div>
                            <?php
                        } else {
                            
                        }
                        ?>
                        <?php if ($show_form == 'Yes') { ?>
                            <div class="col-sm-5 col-md-4 pull-right hidden-xs">
                                <div class="find-drive <?php
                                if ($type_form == '2') {
                                    echo 'sec-form';
                                } else {
                                    
                                }
                                ?>">
                                    <h5><?php echo esc_attr($title_search); ?> <i class="fa fa-road"></i></h5>
                                    <div class="drive-form">
                                        <div class="intres-lesson"> 

                                            <?php if ($which_form == 'normal_form') { ?>

                                                <!--======= FORM =========-->
                                                <form method="post" action="<?php echo esc_url($theme_option['courses_linksearch']); ?>" >
                                                    <ul class="row">

                                                        <!--======= INPUT NAME =========-->
                                                        <li class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="sl_name" placeholder="<?php esc_html_e('Your Name', 'driveme') ?>" >
                                                                <span class="fa fa-user"></span> </div>
                                                        </li>

                                                        <!--======= INPUT EMAIL =========-->
                                                        <li class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="email" name="sl_email" class="form-control" placeholder="<?php esc_html_e('Your Email', 'driveme') ?>" >
                                                                <span class="fa fa-envelope"></span> </div>
                                                        </li>

                                                        <!--======= INPUT PHONE NUMBER =========-->
                                                        <li class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="text" name="sl_phone" class="form-control" placeholder="<?php esc_html_e('Phone', 'driveme') ?>" >
                                                                <span class="fa fa-phone"></span> </div>
                                                        </li>

                                                        <!--======= INPUT PHONE NUMBER =========-->
                                                        <li class="col-sm-6">
                                                            <div class="form-group">
                                                                <input type="text" name="courses-date" class="form-control" id="datepicker" placeholder="DD/MM/YY" name="courses-date">
                                                                <span class="fa fa-calendar"></span> </div>
                                                        </li>

                                                        <!--======= INPUT SELECT =========-->
                                                        <li class="col-sm-6">
                                                            <div class="form-group">
                                                                <select name="courses-type">
                                                                    <?php
                                                                    $args = array(
                                                                        'post_type' => 'courses',
                                                                    );
                                                                    $wp_query = new WP_Query($args);
                                                                    $i = 1;
                                                                    $countrys = array();

                                                                    // $countrys[0]=$name1;
                                                                    while ($wp_query->have_posts()): $wp_query->the_post();
                                                                        $cat_name = '';
                                                                        $categories = get_the_terms(get_the_ID(), 'categories');
                                                                        if ($categories && !is_wp_error($categories)) :
                                                                            foreach ((array) $categories as $categorie) {
                                                                                $cat_name = $categorie->name;
                                                                                $slug = $categorie->slug;
                                                                            }
                                                                        endif;
                                                                        if (!in_array($cat_name, $countrys) && $cat_name != '') {
                                                                            $countrys[$i] = $cat_name;
                                                                            $i++;
                                                                            echo '<option value="' . $cat_name . '">' . $cat_name . '</option>';
                                                                        }
                                                                    endwhile;
                                                                    wp_reset_query();
                                                                    ?>
                                                                </select>
                                                                <span class="fa fa-file-text-o"></span> </div>
                                                        </li>

                                                        <!--======= INPUT SELECT =========-->
                                                        <li class="col-sm-6">
                                                            <div class="form-group">
                                                                <select name="courses-car">
                                                                    <option value="null">Car Type</option>
                                                                    <?php
                                                                    $args = array(
                                                                        'post_type' => 'courses',
                                                                    );
                                                                    $wp_query = new WP_Query($args);
                                                                    $i = 1;
                                                                    $nam = array();
                                                                    $nam[0] = get_post_meta($id, '_cmb_courses_car', true);
                                                                    while ($wp_query->have_posts()): $wp_query->the_post();
                                                                        $value = get_post_meta(get_the_ID(), '_cmb_courses_car', true);

                                                                        if (!in_array($value, $nam) && $value != '') {
                                                                            $nam[$i] = $value;
                                                                            ?>
                                                                            <option value="<?php echo get_post_meta(get_the_ID(), '_cmb_courses_car', true); ?>"><?php echo get_post_meta(get_the_ID(), '_cmb_courses_car', true); ?></option>
                                                                            <?php
                                                                        }$i++;
                                                                    endwhile;
                                                                    wp_reset_query();
                                                                    ?>
                                                                </select>
                                                                <span class="fa fa-car"></span> </div>
                                                        </li>

                                                        <!--======= INPUT SELECT =========-->
                                                        <li class="col-sm-6">
                                                            <div class="form-group">
                                                                <select name="courses-time">
                                                                    <option value="null"><?php esc_html_e('Time', 'driveme') ?></option>
                                                                    <?php
                                                                    $args = array(
                                                                        'post_type' => 'courses',
                                                                    );
                                                                    $wp_query = new WP_Query($args);
                                                                    $i = 1;
                                                                    $name = array();
                                                                    $name[0] = get_post_meta($id, '_cmb_courses_time', true);
                                                                    while ($wp_query->have_posts()): $wp_query->the_post();
                                                                        $values = get_post_meta(get_the_ID(), '_cmb_courses_time', true);

                                                                        if (!in_array($values, $name) && $values != '') {
                                                                            $name[$i] = $values;
                                                                            ?>
                                                                            <option value="<?php echo get_post_meta(get_the_ID(), '_cmb_courses_time', true); ?>"><?php echo get_post_meta(get_the_ID(), '_cmb_courses_time', true); ?></option>
                                                                            <?php
                                                                        }$i++;
                                                                    endwhile;
                                                                    wp_reset_query();
                                                                    ?>
                                                                </select>
                                                                <span class="fa fa-clock-o"></span> </div>
                                                        </li>
                                                    </ul>

                                                    <!--======= BUTTON =========-->
                                                    <div class="text-center">
                                                        <button type="submit" class="btn"><?php echo esc_attr($title_button); ?></button>
                                                        <input type="hidden" name="slider_search" value="1"/>
                                                    </div>
                                                </form>
                                            <?php } else { ?>
                                                <?php echo do_shortcode('[contact-form-7 id="' . $contact_form7 . '" title="Contact Form"] '); ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        ?>
                    </div>
                </div>
            </li>
        <?php } ?>
        <?php
    }
    ?>


    <?php
    return ob_get_clean();
}

//testimonials
add_shortcode('testimonials', 'testimonials_func');

function testimonials_func($atts, $content = null) {
    extract(shortcode_atts(array(
        'title' => '',
        'content11' => '',
        'job' => '',
        'type' => '1',
        'position1' => '',
        'image' => '',
                    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image, '');
    ?> 
    <?php if ($type == '1') { ?>
        <div class="testi">
            <div class="avatr"> <img src="<?php echo esc_url($images[0]); ?>" alt="" > </div>
            <div class="feed-text">
                <p><?php echo wp_specialchars_decode($content11); ?></p>
                <h5><?php echo wp_specialchars_decode($title); ?> <span> - <?php echo wp_specialchars_decode($job); ?></span></h5>
            </div>
        </div>

    <?php } elseif ($type == '2left') { ?>
        <li data-target="#carousel-example-generic" data-slide-to="<?php echo $position1; ?>" class="<?php
        if ($position1 == '0') {
            echo 'active';
        }
        ?>"> <span class="feeder-name animated flipInY"><i class="fa fa-comments-o"></i></span> <img src="<?php echo esc_url($images[0]); ?>" alt="" > </li>
        <?php } elseif ($type == '2right') { ?>
        <div class="item <?php
        if ($position1 == '0') {
            echo 'active';
        }
        ?>">
            <p><?php echo wp_specialchars_decode($content11); ?></p>
            <h5><?php echo wp_specialchars_decode($title); ?> -<span> <?php echo wp_specialchars_decode($job); ?> </span></h5>
        </div>
    <?php } elseif ($type == '3') { ?>
        <div class="testi">
            <div class="feed-text">
                <p><?php echo wp_specialchars_decode($content11); ?></p>
                <h5><h5><?php echo wp_specialchars_decode($title); ?> <span> - <?php echo wp_specialchars_decode($job); ?> </span></h5>
            </div>
        </div>
    <?php } ?>

    <?php
    return ob_get_clean();
}

//features
add_shortcode('features', 'features_func');

function features_func($atts, $content = null) {
    extract(shortcode_atts(array(
        'title' => '',
        'type' => '1',
        'animation' => '0',
        'content11' => '',
        'icon' => '',
        'text' => '',
        'link' => '#',
                    ), $atts));
    ob_start();
    ?> 
    
            <?php if ($animation == '0') { ?> 
                <li class="col-sm-6 col-md-3">
                <?php } elseif ($animation == '1') { ?>
                <li class="col-sm-6 col-md-3 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.4s">
                <?php } elseif ($animation == '2') { ?>
                <li class="col-sm-6 col-md-3  wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.5s">
                <?php } elseif ($animation == '3') { ?>
                <li class="col-sm-6 col-md-3  wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.6s">
                <?php } elseif ($animation == '4') { ?>
                <li class="col-sm-6 col-md-3  wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.7s">
                <?php } ?>

                <div class="inner">
                    <div class="hexagon"><span> </span></div>
                    <div class="icon"> <i class="fa <?php echo $icon; ?>"></i> </div>
                    <h5><?php echo wp_specialchars_decode(esc_attr($title)); ?></h5>
                    <hr>
                    <p><?php echo wp_specialchars_decode(esc_attr($content11)); ?></p>
                    <a href="<?php echo esc_url($link); ?>"><?php echo wp_specialchars_decode(esc_attr($text)); ?></a> </div>
            </li>

            



    <?php
    return ob_get_clean();
}

//gallery
add_shortcode('gallery11', 'gallery11_func');

function gallery11_func($atts, $content = null) {
    extract(shortcode_atts(array(
        'title' => '',
        'desc' => '',
        'id' => '',
        'show' => '6',
        'text' => '',
        'text2' => '',
        'view' => '',
        'link' => '',
        'orderby' => 'title',
        'orderpost' => 'ASC',
        'animation' => 'no',
                    ), $atts));
    ob_start();
    ?> 

    <section id="<?php echo esc_attr($id); ?>">

        <div class="portfolio portfolio-filter">

            <div class="container"> 

                <!--======= TITTLE =========-->

                <?php if ($animation == 'no') { ?> 

                    <div class="tittle">

                    <?php } elseif ($animation == 'yes') { ?>

                        <div class="tittle wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.4s">

                        <?php } ?>

                        <h3><?php echo wp_specialchars_decode(esc_attr($title)); ?></h3>

                        <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>

                        <hr>

                    </div>

                </div>

                <!--======= PORTFOLIO ITEMS =========-->

                <?php if ($animation == 'no') { ?> 

                    <div class="portfolio-wrapper">

                    <?php } elseif ($animation == 'yes') { ?>

                        <div class="portfolio-wrapper wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.4s">

                        <?php } ?>



                        <div class="container"> 



                            <!--======= PORTFOLIO FILTER =========-->

                            <ul class="filter">

                                <li><a class="active" href="#." data-filter="*"><?php echo $text; ?></a></li>

                                <?php
                                $categories = get_terms('skills');

                                foreach ((array) $categories as $categorie) {

                                    $cat_name = $categorie->name;

                                    $cat_slug = $categorie->slug;
                                    ?>

                                    <li><a href="#" data-filter=".<?php echo $cat_slug ?>"><?php echo $cat_name ?> </a></li>

                                <?php } ?>

                            </ul>

                            <ul class="items col-4">

                                <!--======= PORTFOLIO ITEM =========-->

                                <?php
                                $args = array(
                                    'post_type' => 'gallery',
                                    'posts_per_page' => $show,
                                    'order' => $orderpost,
                                    'orderby' => $orderby,
                                );

                                $wp_query = new WP_Query($args);

                                $i = 1;

                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                    $location = get_post_meta(get_the_ID(), '_cmb_gallery_location', true);

                                    $params = array('width' => 263, 'height' => 263);

                                    $image = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);

                                    $cates = get_the_terms(get_the_ID(), 'skills');

                                    $cate_name = '';

                                    $cate_slug = '';

                                    foreach ((array) $cates as $cate) {

                                        if (count($cates) > 0) {

                                            $cate_name .= $cate->name . ' ';

                                            $cate_slug .= $cate->slug . ' ';
                                        }
                                    }
                                    ?>

                                    <li class="item <?php echo $cate_slug; ?>">

                                        <div class="port-over"> <img  src="<?php echo esc_url($image); ?>" alt="" >

                                            <div class="over-info">

                                                <h4><?php the_title(); ?></h4>

                                                <p><?php echo $text2; ?> <?php echo $location ?></p>
                                                <div class="gallery-pop"> <a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id()) ?>" data-source="<?php echo wp_get_attachment_url(get_post_thumbnail_id()) ?>" title="Into The Blue" ><i class="fa fa-search"></i></a> </div>
                                                <a href="#."><i class="fa fa-heart"></i></a> </div>

                                        </div>

                                    </li>

                                    <?php
                                    $i++;

                                endwhile;
                                ?>

                                <!--======= PORTFOLIO ITEM =========-->



                                <!--======= PORTFOLIO ITEM =========-->



                                <!--======= PORTFOLIO ITEM =========-->



                            </ul>

                            <!--======= BUTTON =========-->

                            <div class="text-center"> <a href="<?php echo esc_url($link); ?>" class="btn"><?php echo wp_specialchars_decode($view); ?></a> </div>

                        </div>

                    </div>

                </div>

                </section>




                <?php
                return ob_get_clean();
            }

//ourcourses
            add_shortcode('ourcourses', 'ourcourses_func');

            function ourcourses_func($atts, $content = null) {
                extract(shortcode_atts(array(
                    'title' => '',
                    'desc' => '',
                    'id' => '',
                    'show' => '4',
                    'view' => '',
                    'link' => '',
                    'orderby' => 'title',
                    'orderpost' => 'ASC',
                    'animation' => 'no',
                                ), $atts));
                ob_start();
                global $theme_option;
                ?> 

                <section id="<?php echo esc_attr($id); ?>" class="products">

                    <div class="container"> 

                        <!--======= TITTLE =========-->

                        <?php if ($animation == 'no') { ?> 

                            <div class="tittle">

                            <?php } elseif ($animation == 'yes') { ?>

                                <div class="tittle wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.4s">

                                <?php } ?>

                                <h3><?php echo wp_specialchars_decode($title); ?></h3>

                                <p><?php echo wp_specialchars_decode($desc); ?></p>

                                <hr>

                            </div>



                            <!--======= PRODUCTS ROW =========-->

                            <ul class="row">

                                <?php
                                $i = 0;

                                $args = array(
                                    'post_type' => 'courses',
                                    'posts_per_page' => $show,
                                    'order' => $orderpost,
                                    'orderby' => $orderby,
                                );

                                $wp_query = new WP_Query($args);

								$cnt=count($wp_query->posts);

                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                    $i++;

                                    $ratings = get_post_meta(get_the_ID(), '_cmb_courses_rate', true);

                                    $prices = get_post_meta(get_the_ID(), '_cmb_courses_price', true);



                                    $params = array('width' => 261, 'height' => 222);

                                    $thumbnails = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);

                                    $categorie_names = '';

                                    $categories = get_the_terms(get_the_ID(), 'categories');

                                    foreach ((array) $categories as $categorie) {

                                        if (count($categories) == 0) {

                                            $categorie_names .= $categorie->name;
                                        } elseif (count($categories) == 1) {
                                            $categorie_names .= $categorie->name;
                                        } else {
                                            //$categorie_names .= $categorie->name . ' , ';
                                            $categorie_names .= '<span class="multi-cat">' . $categorie->name . ' , </span>';
                                        }
                                    }
                                    ?>

                                    

                                            

                                            <?php if ($animation == 'no') { ?> 

                                                <li class="col-sm-6 col-md-3">

                                                <?php } elseif ($animation == 'yes') { ?>

                                                    <?php if ($i % 4 == 1) { ?>

                                                    <li class="col-sm-6 col-md-3 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.4s">

                                                    <?php } elseif ($i % 4 == 2) { ?>

                                                    <li class="col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.4s">

                                                    <?php } elseif ($i % 4 == 3) { ?>

                                                    <li class="col-sm-6 col-md-3 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.4s">

                                                    <?php } elseif ($i % 4 == 0) { ?>

                                                    <li class="col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.4s">

                                                    <?php } ?>

                                                <?php } ?>

                                                <div class="prodct"> 



                                                    <!--======= IMAGE =========--> 

                                                    <img class="img-responsive" src="<?php echo esc_url($thumbnails); ?>" alt="">

                                                    <div class="pro-info"> 



                                                        <!--======= ITEM NAME / RATING =========-->

                                                        <div class="cate-name"> <span class="pull-left"><?php echo $categorie_names; ?></span>

                                                            <ul class="stars pull-right">

                                                                <li <?php
                                                                if ($ratings == 'zero') {
                                                                    echo 'class="no-rate"';
                                                                } else {
                                                                    
                                                                }
                                                                ?>><i class="fa fa-star"></i></li>

                                                                <li <?php
                                                                if ($ratings == 'zero' || $ratings == 'one') {
                                                                    echo 'class="no-rate"';
                                                                } else {
                                                                    
                                                                }
                                                                ?>><i class="fa fa-star"></i></li>

                                                                <li <?php
                                                                if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two') {
                                                                    echo 'class="no-rate"';
                                                                } else {
                                                                    
                                                                }
                                                                ?>><i class="fa fa-star"></i></li>

                                                                <li <?php
                                                                if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three') {
                                                                    echo 'class="no-rate"';
                                                                } else {
                                                                    
                                                                }
                                                                ?>><i class="fa fa-star"></i></li>

                                                                <li <?php
                                                                if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three' || $ratings == 'four') {
                                                                    echo 'class="no-rate"';
                                                                } else {
                                                                    
                                                                }
                                                                ?>><i class="fa fa-star"></i></li>

                                                            </ul>

                                                        </div>



                                                        <!--======= ITEM Details =========--> 

                                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>

                                                        <hr>

                                                        <span class="price"><?php echo esc_attr($prices); ?></span> 
                                                        <?php
														$courseid=get_the_ID();
														$bookingtype=get_post_meta($courseid,'_cmb_booking_type',true);
	if($bookingtype=='default'||empty($bookingtype)){?>
		<form method="post" action="<?php echo esc_url($theme_option['courses_linkbooking']); ?>" id="booking_form">
                                                            <button type="submit" class="btn booking_form"><?php echo esc_attr($theme_option['courses_booknow']) ?></button> 
                                                            <input type="hidden" name="booking_title" value="<?php echo $courseid; ?>" />
                                                        </form>
	<?php }
	elseif($bookingtype=='external'){
		$external_link=get_post_meta($courseid,'_cmb_booknow_externallink',true);
		if($external_link!=''){
		?>
        <a href="<?php echo $external_link?>" class="btn booking_form"><?php echo esc_attr($theme_option['courses_booknow']) ?></a> 
	<?php }else{?>
	<form method="post" action="<?php echo esc_url($theme_option['courses_linkbooking']); ?>" id="booking_form">
                                                            <button type="submit" class="btn booking_form"><?php echo esc_attr($theme_option['courses_booknow']) ?></button> 
                                                            <input type="hidden" name="booking_title" value="<?php echo $courseid; ?>" />
                                                        </form>
	<?php }}
	elseif($bookingtype=='woocommerce'){
		$woo_product_id=get_post_meta($courseid,'_cmb_booknow_woocommerce',true);
		if($woo_product_id!=''){?>
        <a href="<?php echo site_url().'/?add-to-cart='.$woo_product_id?>" class="btn booking_form"><?php echo esc_attr($theme_option['courses_booknow']) ?></a> 
		<?php }else{?>
		<form method="post" action="<?php echo esc_url($theme_option['courses_linkbooking']); ?>" id="booking_form">
                                                            <button type="submit" class="btn booking_form"><?php echo esc_attr($theme_option['courses_booknow']) ?></button> 
                                                            <input type="hidden" name="booking_title" value="<?php echo $courseid; ?>" />
                                                        </form>
		<?php }
	} 
														?>
                                                        <a href="<?php the_permalink(); ?>" class="btn btn-1"><?php echo esc_attr($theme_option['courses_detail']); ?></a> </div>

                                                </div>

                                            </li>

                                            <?php if ($i % 4 == 0 && $cnt>$i) { ?>

                                            </ul>
											
                                                <ul class="row">
											
                                        

                                    <?php } ?>

                                    

                                <?php endwhile; ?>

                            </ul>

                            <div class="text-center margin-t-40"> <a href="<?php echo esc_url($link); ?>" class="btn"><?php echo wp_specialchars_decode($view); ?></a> </div>

                        </div>

                </section>





                <?php
                return ob_get_clean();
            }

//video
 add_shortcode('video', 'video_func');
function video_func($atts, $content = null){
    extract(shortcode_atts(array(
        'title' => '',
        'desc' => '',
        'icon' => '',
        'link' => '',
        'id' => '',
        'image' => '',
    ), $atts));
    ob_start(); 
    $images = wp_get_attachment_image_src($image,'');
    ?> 
    <section id="video" vid="<?php echo esc_attr($id); ?>" data-stellar-background-ratio="0.2" style="background: url(<?php echo esc_url($images[0]);?>) fixed no-repeat;">
      <div class="container text-center">
        <h1><?php echo wp_specialchars_decode($title); ?></h1>
        <h3><?php echo wp_specialchars_decode($desc); ?></h3>
         <a href=".small-vedio-<?php echo esc_attr($id); ?>" class="link popup-vedio video-btn"><i class="fa <?php echo $icon;?>"></i></a>
        </div>
    </section>
        
    <!--======= POPUP VIDEO =========-->
    <div id="small-vedio" class="zoom-anim-dialog mfp-hide small-vedio-<?php echo esc_attr($id); ?>">
      <div class="pop_up">
        <iframe src="<?php echo esc_url($link);?>"></iframe>
      </div>
    </div>



<?php  return ob_get_clean();
} 


//price
            add_shortcode('price', 'price_func');

            function price_func($atts, $content = null) {
                extract(shortcode_atts(array(
                    'title' => '',
                    'desc' => '',
                    'id' => '',
                    'show' => '4',
                    'orderby' => 'title',
                    'orderpost' => 'ASC',
                    'animation' => 'no',
                    'type' => 'type1',
                                ), $atts));
                ob_start();
                global $theme_option;
                ?> 
                <?php if ($type == 'type1') { ?>
                    <section id="pricing">
                        <div class="container"> 
                            <!--======= TITTLE =========-->
                            <?php if ($animation == 'no') { ?> 
                                <div class="tittle">
                                <?php } elseif ($animation == 'yes') { ?>
                                    <div class="tittle wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                    <?php } ?>

                                    <h3><?php echo wp_specialchars_decode(esc_attr($title)); ?></h3>
                                    <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>
                                    <hr>
                                </div>

                                <!--======= PRICING ROW =========-->
                                <ul class="row">
                                  <?php
                                    $i = 0;
                                    $args = array(
                                        'post_type' => 'courses',
                                        'posts_per_page' => $show,
                                        'order' => $orderpost,
                                        'orderby' => $orderby,
                                    );
                                    $wp_query = new WP_Query($args);

                                    while ($wp_query->have_posts()) : $wp_query->the_post();
                                        $i++;
                                        $ratings = get_post_meta(get_the_ID(), '_cmb_courses_rate', true);
                                        $prices = get_post_meta(get_the_ID(), '_cmb_courses_price', true);

                                        $params = array('width' => 270, 'height' => 270);
                                        $thumbnails = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);
                                        $categorie_names = '';
                                        $categories = get_the_terms(get_the_ID(), 'categories');
                                        foreach ((array) $categories as $categorie) {
                                            if (count($categories) > 0) {
                                                $categorie_names .= $categorie->name . '  ';
                                            }
                                        }
                                        ?>                                              

                                                <!--======= PRICE TABLE 1 =========-->
                                                <?php if ($animation == 'no') { ?> 
                                                    <li class="col-sm-6 col-md-3">
                                                    <?php } elseif ($animation == 'yes') { ?>
                                                        <?php if ($i % 2 == 1) { ?>
                                                        <li class="wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                                        <?php } elseif ($i % 2 == 0) { ?>
                                                        <li class="wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                                        <?php } ?>
                                                    <?php } ?>
                                                    <div class="price-inner">
                                                        <div class="price-head">
                                                            <h4><?php echo wp_specialchars_decode(get_post_meta(get_the_ID(), '_cmb_courses_title1', true)); ?></h4>
                                                            <span><?php echo $prices; ?></span> </div>
                                                        <?php echo wp_specialchars_decode(get_post_meta(get_the_ID(), '_cmb_courses_desc', true)); ?>
                                                        <?php if ($ratings == 'zero') { ?>
                                                            <p></p>
                                                        <?php } elseif ($ratings == 'one') { ?>
                                                            <p><i class="fa fa-star"></i></p>
                                                        <?php } elseif ($ratings == 'two') { ?>
                                                            <p><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                        <?php } elseif ($ratings == 'three') { ?>
                                                            <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                        <?php } elseif ($ratings == 'four') { ?>
                                                            <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                        <?php } elseif ($ratings == 'five') { ?>
                                                            <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                        <?php } ?>
                                                        <p class="check-gr"><i class="fa <?php echo get_post_meta(get_the_ID(), '_cmb_courses_icon', true); ?>"></i> </p>
                                                        <a href="<?php the_permalink(); ?>" class="btn"><?php echo esc_attr($theme_option['courses_choose']) ?></a> 
                                                    </div>
                                                </li>                                                                                    
                                    <?php endwhile; ?>
                                        </ul>
                                </div>
                            </div>
                    </section>
                <?php } elseif ($type == 'type2') { ?>
                    <section id="pricing" class="pricing-2">
                        <div class="container"> 
                            <!--======= TITTLE =========-->
                            <div class="tittle">
                                <h3><?php echo wp_specialchars_decode(esc_attr($title)); ?></h3>
                                <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>
                                <hr>
                            </div>
                            <div class="nav-tabs">
                                <ul class="nav nav-pills">
                                    <?php
                                    $i = 0;
                                    $tags = get_terms('tags');
                                    foreach ((array) $tags as $tag) {
                                        $tag_name = $tag->name;
                                        $tag_slug = $tag->slug;
                                        $i++;
                                        ?>
                                        <li role="presentation" class="<?php
                                        if ($i == 1) {
                                            echo active;
                                        }
                                        ?>"><a href="#<?php echo $tag_slug; ?>" aria-controls="founder" role="tab" data-toggle="tab"><?php echo $tag_name; ?></a></li>
                                        <?php } ?>
                                </ul>
                            </div>

                            <!--======= TAB CONTENT =========-->
                            <div class="tab-content"> 
                                <?php
                                $i = 0;
                                $tags = get_terms('tags');
                                foreach ((array) $tags as $tag) {
                                    $tag_name = $tag->name;
                                    $tag_slug = $tag->slug;
                                    $i++;
                                    ?>
                                    <!--======= HOURLY =========-->
                                    <div role="tabpanel" class="tab-pane <?php
                                    if ($i == 1) {
                                        echo 'active';
                                    }
                                    ?>" id="<?php echo $tag_slug; ?>"> 
                                        <!--======= PRICING ROW =========-->
                                        <div class="row">
                                            <?php
                                            $b = 0;
                                            $args = array(
                                                'post_type' => 'courses',
                                                'posts_per_page' => $show,
                                                'order' => $orderpost,
                                                'orderby' => $orderby,
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'tags',
                                                        'field' => 'slug',
                                                        'terms' => $tag_slug,
                                                    ),
                                                ),
                                            );
                                            $wp_query = new WP_Query($args);

                                            while ($wp_query->have_posts()) : $wp_query->the_post();
                                                $b++;
                                                $ratings = get_post_meta(get_the_ID(), '_cmb_courses_rate', true);
                                                $prices = get_post_meta(get_the_ID(), '_cmb_courses_price', true);

                                                $params = array('width' => 270, 'height' => 270);
                                                $thumbnails = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);
                                                ?>

                                                <div class="col-md-3">
                                                    <ul class="row">


                                                        <!--======= PRICE TABLE 1 =========-->
                                                        <li class="col-sm-12">
                                                            <div class="price-inner">
                                                                <div class="price-head">
                                                                    <h4><?php echo wp_specialchars_decode(get_post_meta(get_the_ID(), '_cmb_courses_title2', true)); ?></h4>
                                                                    <span><?php echo $prices; ?></span> </div>
                                                                <?php echo wp_specialchars_decode(get_post_meta(get_the_ID(), '_cmb_courses_desc', true)); ?>
                                                                <?php if ($ratings == 'zero') { ?>
                                                                    <p></p>
                                                                <?php } elseif ($ratings == 'one') { ?>
                                                                    <p><i class="fa fa-star"></i></p>
                                                                <?php } elseif ($ratings == 'two') { ?>
                                                                    <p><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                                <?php } elseif ($ratings == 'three') { ?>
                                                                    <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                                <?php } elseif ($ratings == 'four') { ?>
                                                                    <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                                <?php } elseif ($ratings == 'five') { ?>
                                                                    <p><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></p>
                                                                <?php } ?>
                                                                <p class="check-gr"><i class="fa <?php echo get_post_meta(get_the_ID(), '_cmb_courses_icon', true); ?>"></i> </p>
                                                                <a href="<?php the_permalink(); ?>" class="btn"><?php echo esc_attr($theme_option['courses_choose']) ?></a> </div>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <?php
                                                if ($b % 4 == 0) {
                                                    ?>
                                                </div>
                                                <div class="row">
                                                    <?php
                                                }
                                                ?>
                                                <!--======= PRICE TABLE 2 =========-->
                                            <?php endwhile; ?>
                                            <!--======= PRICE TABLE 2 =========-->

                                        </div>
                                    </div>
                                <?php } ?>
                                <!--======= MONTHLY =========-->

                            </div>
                        </div>
                    </section>
                <?php } ?>


                <?php
                return ob_get_clean();
            }

//contactsearch
            add_shortcode('contactsearch', 'contactsearch_func');

            function contactsearch_func($atts, $content = null) {
                extract(shortcode_atts(array(
                    'title' => '',
                    'subtitle' => '',
                    'desc' => '',
                    'geta' => '',
                    'page_search' => '',
                    'color' => '',
                    'image' => '',
                    'animation' => 'no',
                    'contact_form7' => '',
                    'which_form' => '',
                                ), $atts));
                ob_start();
                global $theme_option;
                $effect = $efects = '';

                $images = wp_get_attachment_image_src($image, '');
                
                global $theme_option;
                if ($animation == 'no') {
                    $effect = 'wow fadeInUp';
                    $efects = 'data-wow-duration="0.5s" data-wow-delay="0.4s"';
                } elseif ($animation == 'yes') {
                    $effect = '';
                    $efects = '';
                } 
                ?>
                <!--======= INTRESTED =========-->
                <section  id="intrested" class="intrested" <?php if ($image != '') { ?>style="background: <?php echo esc_attr($color); ?> url(<?php echo esc_url($images['0']); ?>) fixed no-repeat;background-size: cover;" <?php
                }
                ?>>
                    <div class="container"> 
                        <!--======= TITTLE =========-->
                        <div class="tittle <?php if(!empty($effect)) { echo esc_attr($effect); } ?>" <?php if(!empty($effect)) { echo esc_attr($effects); } ?>>
                            <?php if ($title != '') { ?>
                                <h3><?php echo esc_attr($title); ?></h3>
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($subtitle != '') { ?>
                                <p><?php echo esc_attr($subtitle); ?></p>
                                <?php
                            } else {
                                
                            }
                            ?>
                            <?php if ($title != '') { ?>
                                <hr>
                                <?php
                            } else {
                                
                            }
                            ?>
                        </div>
                        <div class="intres-lesson">
                            <h3><?php echo esc_attr($desc); ?></h3>

                            <?php if ($which_form == 'quote_form') { ?>

                                <!--======= FORM =========-->
                                <form method="post" action="<?php echo esc_url($page_search); ?>">
                                    <ul class="row">

                                        <!--======= INPUT NAME =========-->
                                        <li class="col-sm-3 <?php echo esc_attr($effect); ?>" <?php echo esc_attr($effects); ?>>
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="Name" placeholder="<?php esc_html_e('Your Name', 'driveme') ?>" required value="<?php if (isset($_POST['Name'])) echo $_POST['Name']; ?>">
                                                <span class="fa fa-user"></span> </div>
                                        </li>

                                        <!--======= INPUT EMAIL =========-->
                                        <li class="col-sm-3 <?php echo esc_attr($effect); ?>" <?php echo esc_attr($effects); ?>>
                                            <div class="form-group">
                                                <input type="email" class="form-control" name="Email" placeholder="<?php esc_html_e('Your Email', 'driveme') ?>" required value="<?php if (isset($_POST['Email'])) echo $_POST['Email']; ?>">
                                                <span class="fa fa-envelope"></span> </div>
                                        </li>

                                        <!--======= INPUT PHONE NUMBER =========-->
                                        <li class="col-sm-3 <?php echo esc_attr($effect); ?>" <?php echo esc_attr($effects); ?>>
                                            <div class="form-group">
                                                <input type="text" name="Phone" class="form-control" placeholder="<?php esc_html_e('Phone', 'driveme') ?>" required value="<?php if (isset($_POST['Phone'])) echo $_POST['Phone']; ?>">
                                                <span class="fa fa-phone"></span> </div>
                                        </li>

                                        <!--======= INPUT SELECT =========-->
                                        <li class="col-sm-3 <?php echo esc_attr($effect); ?>" <?php echo esc_attr($effects); ?>>
                                            <div class="form-group">
                                                <select name="courses-type">
                                                    <?php
                                                    $args = array(
                                                        'post_type' => 'courses',
                                                    );
                                                    $wp_query = new WP_Query($args);
                                                    $i = 1;
                                                    $countrys = array();
                                                    // $countrys[0]=$name1;
                                                    while ($wp_query->have_posts()): $wp_query->the_post();
                                                        $cat_name = '';
                                                        $categories = get_the_terms(get_the_ID(), 'categories');
                                                        if ($categories && !is_wp_error($categories)) :
                                                            foreach ((array) $categories as $categorie) {
                                                                $cat_name = $categorie->name;
                                                                $slug = $categorie->slug;
                                                            }
                                                        endif;
                                                        if (!in_array($cat_name, $countrys) && $cat_name != '') {
                                                            $countrys[$i] = $cat_name;
                                                            $i++;
                                                            echo '<option value="' . $cat_name . '">' . $cat_name . '</option>';
                                                        }
                                                    endwhile;
                                                    ?>
                                                </select>
                                                <span class="fa fa-file-text-o"></span> </div>
                                        </li>
                                    </ul>

                                    <!--======= BUTTON =========-->
                                    <div class="text-center <?php echo esc_attr($effect); ?>" <?php echo esc_attr($effects); ?>>
                                        <button type="submit" class="btn"><?php echo esc_attr($geta); ?></button>
                                    </div>
                                </form>
                            <?php } else { ?>
                                <?php echo do_shortcode('[contact-form-7 id="' . $contact_form7 . '" title="Contact Form"] '); ?>
                            <?php } ?>

                        </div>
                    </div>
                </section>



                <?php
                return ob_get_clean();
            }

//inspectors
            add_shortcode('inspectors', 'inspectors_func');

            function inspectors_func($atts, $content = null) {
                extract(shortcode_atts(array(
                    'title' => '',
                    'desc' => '',
                    'id' => '',
                    'show' => '4',
                    'orderby' => 'title',
                    'orderpost' => 'ASC',
                    'animation' => 'no',
                                ), $atts));
                ob_start();
                global $theme_option;
                ?> 
                <section class="inspectors" id="inspectors">
                    <div class="container"> 

                        <!--======= TITTLE =========-->
                        <?php if ($animation == 'no') { ?> 
                            <div class="tittle">
                            <?php } elseif ($animation == 'yes') { ?>
                                <div class="tittle wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                <?php } ?>
                                <h3><?php echo wp_specialchars_decode(esc_attr($title)); ?></h3>
                                <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>
                                <hr>
                            </div>

                            <!--======= INSPECTORS ROW =========-->
                            <ul class="row">
                                <?php
                                $i = 0;
                                $args = array(
                                    'post_type' => 'inspectors',
                                    'posts_per_page' => $show,
                                    'order' => $orderpost,
                                    'orderby' => $orderby,
                                );
                                $wp_query = new WP_Query($args);
								$cnt=count($wp_query->posts);
                                while ($wp_query->have_posts()) : $wp_query->the_post();
                                    $i++;
                                    //$ratings=get_post_meta(get_the_ID(),'_cmb_courses_rate', true);

                                    $params = array('width' => 270, 'height' => 270);
                                    $thumbnails = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);
                                    $categorie_names = '';
                                    $categories = get_the_terms(get_the_ID(), 'specialized');
                                    foreach ((array) $categories as $categorie) {
                                        if (count($categories) > 0) {
                                            $categorie_names .= $categorie->name . '  ';
                                        }
                                    }
                                    ?>
                                    
                                        <?php if ($animation == 'no') { ?> 
                                            <li class="col-sm-6 col-md-3">
                                                
                                                <?php } elseif ($animation == 'yes') { ?>
                                                    
                                                            <!--======= INSPECTORS TEACHER =========-->
                                                            
                                                                    <?php if ($i % 4 == 1) { ?>
                                                                    <li class="col-sm-6 col-md-3">
                                                                    <?php } elseif ($i % 4 == 2) { ?>
                                                                    <li class="col-sm-6 col-md-3 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                                                    <?php } elseif ($i % 4 == 3) { ?>
                                                                    <li class="col-sm-6 col-md-3">
                                                                    <?php } elseif ($i % 4 == 0) { ?>
                                                                    <li class="col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.4s">
                                                                    <?php } ?>
                                                                <?php }?>
                                                                <div class="teach">
                                                                    <div class="img-sec"> <img class="img-responsive" src="<?php echo esc_url($thumbnails); ?>" alt="" > 

                                                                        <!--=======  TEACHER HOVER =========-->
                                                                        <div class="teach-over"> <a href="<?php the_permalink(); ?>"><i class="fa fa-plus"></i></a> </div>
                                                                    </div>
                                                                    <h6><?php the_title(); ?></h6>
                                                                    <p><span><?php echo $categorie_names; ?></span></p>
                                                                    <p><?php echo driveme_portfolio_excerpt($theme_option['inspectors_excerpt']); ?></p>

                                                                    <!--======= SOCIAL ICON =========-->
                                                                    <ul class="social_icons">
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_inspectors_fb', true) != '') { ?>
                                                                            <li class="facebook"><a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cmb_inspectors_fb', true)); ?>"><i class="fa fa-facebook"></i></a></li>
                                                                        <?php } ?>
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_inspectors_tw', true) != '') { ?>
                                                                            <li class="twitter"><a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cmb_inspectors_tw', true)); ?>"><i class="fa fa-twitter"></i></a></li>
                                                                        <?php } ?>
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_inspectors_gg', true) != '') { ?>
                                                                            <li class="googleplus"><a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cmb_inspectors_gg', true)); ?>"><i class="fa fa-google-plus"></i></a></li>
                                                                        <?php } ?>
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_inspectors_ld', true) != '') { ?>
                                                                            <li class="linkedin"><a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cmb_inspectors_ld', true)); ?>"><i class="fa fa-linkedin"></i></a></li>
                                                                        <?php } ?>
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_inspectors_it', true) != '') { ?>
                                                                            <li class="instagram"><a href="<?php echo esc_url(get_post_meta(get_the_ID(), '_cmb_inspectors_it', true)); ?>"><i class="fa fa-instagram"></i></a></li>
                                                                        <?php } ?>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <?php if ($i % 4 == 0 && $cnt>$i) { ?>
                                                            </ul>
                                                       <ul class="row">
                                                   <?php }?>
                                                <?php endwhile; ?>
                                        </ul>
                                </div>
                                </section>


                                <?php
                                return ob_get_clean();
                            }

//contactsearch
                            add_shortcode('quote', 'quote_func');

                            function quote_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                    'link' => '',
                                    'text' => '',
                                    'class' => 'quote',
                                    'type' => '1',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                ?> 
                                <?php if ($type == '1') { ?>
                                    <section class="<?php echo $class; ?>" id="quote">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-10">
                                                    <h1><?php echo wp_specialchars_decode($title); ?></h1>
                                                    <span><?php echo wp_specialchars_decode($desc); ?></span> </div>
                                                <!--======= GET A QUOTE BUTTOn =========-->
                                                <div class="col-md-2"> <a href="<?php echo esc_url($link); ?>" class="btn"><?php echo wp_specialchars_decode($text); ?></a> </div>
                                            </div>
                                        </div>
                                    </section>
                                <?php } elseif ($type == '2') { ?>
                                    <section class="quote-sim" id="quote">
                                        <div class="container">
                                            <h3 class="pull-left"><?php echo wp_specialchars_decode($title); ?></h3>
                                            <?php echo wp_specialchars_decode($desc); ?>
                                            <!--======= GET A QUOTE BUTTOn =========--> 
                                            <a class="pull-right btn margin-t-20" href="<?php echo esc_url($link); ?>"><?php echo wp_specialchars_decode($text); ?></a> </div>
                                    </section>
                                <?php } ?>

                                <?php
                                return ob_get_clean();
                            }

//inspectors
                            add_shortcode('post', 'post_func');

                            function post_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'show' => '4',
                                    'orderby' => 'title',
                                    'orderpost' => 'ASC',
                                    'animation' => 'no',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                ?> 

                                <div class="news-artical products"> 

                                    <!--======= NEWS SLIDER =========-->
                                    <div class="news-slide"> 
                                        <?php
                                        $i = 0;
                                        $args = array(
                                            'post_type' => 'post',
                                            'posts_per_page' => 3,
                                            'order' => $orderpost,
                                            'orderby' => $orderby,
                                        );
                                        $wp_query = new WP_Query($args);
										
                                        while ($wp_query->have_posts()): $wp_query->the_post();
                                            $i++;
                                            ?>
                                            <!--======= NEWS SLIDER 1 =========-->
                                            <div class="prodct artical"> 

                                                <!--======= IMAGE =========--> 
                                                <?php
                                                $params = array('width' => 268, 'height' => 228);
                                                $image = bfi_thumb(wp_get_attachment_url(get_post_thumbnail_id()), $params);
                                                ?>
                                                <img alt="<?php the_title(); ?>" src="<?php echo $image; ?>" />
                                                <div class="pro-info"> 

                                                    <!--======= ITEM NAME / RATING =========-->
                                                    <div class="cate-name"> <span class="pull-left"><?php the_time('M j, Y'); ?></span>
                                                        <ul class="heart pull-right">
                                                            <li><i class="fa fa-heart"></i></li>
                                                        </ul>
                                                    </div>

                                                    <!--======= ITEM Details =========--> 
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                    <hr>
                                                    <p><?php echo driveme_excerpt($theme_option['blog_excerpt']); ?></p>
                                                    <a href="<?php the_permalink(); ?>" class="btn btn-1"><?php echo esc_attr($theme_option['blog_readmore']); ?></a> 
                                                </div>

                                            </div>

                                            <?php
                                        endwhile;
                                        wp_reset_postdata();
                                        ?>
                                        <!--======= NEWS SLIDER 2 =========-->

                                    </div>
                                </div>


                                <?php
                                return ob_get_clean();
                            }

//faqs
                            add_shortcode('faqs', 'faqs_func');

                            function faqs_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'content1' => '',
                                    'collapsed' => '',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                ?> 
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"> <a data-toggle="collapse" class="<?php
                                            if ($collapsed != 1) {
                                                echo 'collapsed';
                                            }
                                            ?>" data-parent="#accordion" href="#collapse<?php echo $collapsed; ?>"><?php echo wp_specialchars_decode(esc_attr($title)); ?></a> </h4>
                                    </div>

                                    <!--======= ADD INFO HERE =========-->
                                    <div id="collapse<?php echo $collapsed; ?>" class="panel-collapse collapse <?php
                                    if ($collapsed == 1) {
                                        echo 'in';
                                    }
                                    ?>">
                                        <div class="panel-body">
                                            <p><?php echo wp_specialchars_decode(esc_html($content1)); ?></p>
                                        </div>
                                    </div>
                                </div>


                                <?php
                                return ob_get_clean();
                            }

//license
                            add_shortcode('license', 'license_func');

                            function license_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'content1' => '',
                                    'icon' => '',
                                    'image' => '',
                                    'number' => '',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                $images = wp_get_attachment_image_src($image, '');
                                ?> 

                                
                                        <li class="col-sm-6 col-md-3">
                                            <div class="icon-over"> <i class="fa <?php echo esc_attr($icon); ?>"></i> </div>
                                            <div class="lis-img"> <img src="<?php echo esc_url($images['0']); ?>" alt="" > </div>
                                            <h5><?php echo wp_specialchars_decode(esc_attr($title)); ?></h5>
                                            <hr>
                                            <p><?php echo wp_specialchars_decode(esc_attr($content1)); ?></p>
                                        </li>
                                        <?php if ($number % 4 == 0) { ?>
                                        </ul>
     									<ul class="row">
                                <?php } ?>


                                <?php
                                return ob_get_clean();
                            }

//timeline
                            add_shortcode('timeline', 'timeline_func');

                            function timeline_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                    'show' => '6',
                                    'text' => '',
                                    'link' => '',
                                    'orderby' => 'title',
                                    'orderpost' => 'ASC',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                ?> 

                                <section class="time-line">
                                    <div class="container"> 

                                        <!--======= TITTLE =========-->
                                        <div class="tittle">
                                            <h3><?php echo wp_specialchars_decode($title); ?></h3>
                                            <p><?php echo wp_specialchars_decode($desc); ?></p>
                                            <hr>
                                        </div>

                                        <!--======= TIMELINE START =========-->
                                        <div class="time-start">
                                            <div class="row"> 

                                                <!--======= TIMELINE LEFT =========-->
                                                <div class="col-sm-6 no-padding border-rght products">
                                                    <ul class="time-post-l">
                                                        <?php
                                                        $i = 0;
                                                        $args = array(
                                                            'post_type' => 'courses',
                                                            'posts_per_page' => $show,
                                                            'order' => $orderpost,
                                                            'orderby' => $orderby,
                                                        );
                                                        $wp_query = new WP_Query($args);

                                                        while ($wp_query->have_posts()) : $wp_query->the_post();
                                                            $i++;
                                                            $ratings = get_post_meta(get_the_ID(), '_cmb_courses_rate', true);
                                                            $prices = get_post_meta(get_the_ID(), '_cmb_courses_price', true);
                                                            $timeline = get_post_meta(get_the_ID(), '_cmb_courses_timeline', true);
                                                            $params = array('width' => 521, 'height' => 299);
                                                            $image = bfi_thumb(get_post_meta(get_the_ID(), '_cmb_courses_timeline', true), $params);
                                                            $categorie_names = '';
                                                            $categories = get_the_terms(get_the_ID(), 'categories');
                                                            foreach ((array) $categories as $categorie) {
                                                                if (count($categories) > 0) {
                                                                    $categorie_names .= $categorie->name . ' , ';
                                                                }
                                                            }
                                                            ?>
                                                            <?php if ($i % 2 == 1) { ?>
                                                                <!--======= TIMELINE =========-->
                                                                <li> <span class="tym-symble"><i class="fa fa-circle"></i></span>
                                                                    <div class="prodct"> 

                                                                        <!--======= IMAGE =========--> 
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_courses_timeline', true) != '') { ?>
                                                                            <img class="img-responsive" src="<?php echo esc_url($timeline); ?>" alt="">
                                                                        <?php } ?>
                                                                        <div class="pro-info"> 

                                                                            <!--======= ITEM NAME / RATING =========-->
                                                                            <div class="cate-name"> <span class="pull-left"><i class="fa fa-calendar"></i> <?php the_time('j M Y'); ?> / FREE</span>
                                                                                <ul class="stars pull-right">
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three' || $ratings == 'four') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                </ul>
                                                                            </div>

                                                                            <!--======= ITEM Details =========--> 
                                                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                                            <hr>
                                                                            <p><?php echo driveme_portfolio_excerpt($theme_option['courses_excerpt']); ?></p>
                                                                            <a href="<?php the_permalink(); ?>" class="btn"><?php echo esc_attr($theme_option['courses_apply']) ?></a> </div>
                                                                    </div>
                                                                </li>
                                                            <?php } ?>
                                                        <?php endwhile; ?>
                                                        <!--======= TIMELINE =========-->
                                                    </ul>
                                                </div>

                                                <!--======= TIMELINE RIGHT =========-->
                                                <div class="col-sm-6 no-padding products">
                                                    <ul class="time-post-r">
                                                        <?php
                                                        $i = 0;
                                                        $args = array(
                                                            'post_type' => 'courses',
                                                            'posts_per_page' => $show,
                                                            'order' => $orderpost,
                                                            'orderby' => $orderby,
                                                        );
                                                        $wp_query = new WP_Query($args);

                                                        while ($wp_query->have_posts()) : $wp_query->the_post();
                                                            $i++;
                                                            $ratings = get_post_meta(get_the_ID(), '_cmb_courses_rate', true);
                                                            $prices = get_post_meta(get_the_ID(), '_cmb_courses_price', true);
                                                            $timeline = get_post_meta(get_the_ID(), '_cmb_courses_timeline', true);
                                                            $params = array('width' => 521, 'height' => 299);
                                                            $image = bfi_thumb(get_post_meta(get_the_ID(), '_cmb_courses_timeline', true), $params);
                                                            $categorie_names = '';
                                                            $categories = get_the_terms(get_the_ID(), 'categories');
                                                            foreach ((array) $categories as $categorie) {
                                                                if (count($categories) > 0) {
                                                                    $categorie_names .= $categorie->name . ' , ';
                                                                }
                                                            }
                                                            ?>
                                                            <?php if ($i % 2 == 0) { ?>
                                                                <!--======= TIMELINE =========-->
                                                                <li> <span class="tym-symble"><i class="fa fa-circle"></i></span>
                                                                    <div class="prodct"> 

                                                                        <!--======= IMAGE =========--> 
                                                                        <?php if (get_post_meta(get_the_ID(), '_cmb_courses_timeline', true) != '') { ?>
                                                                            <img class="img-responsive" src="<?php echo esc_url($timeline); ?>" alt="">
                                                                        <?php } ?>
                                                                        <div class="pro-info"> 

                                                                            <!--======= ITEM NAME / RATING =========-->
                                                                            <div class="cate-name"> <span class="pull-left"><i class="fa fa-calendar"></i> <?php the_time('j M Y'); ?> / FREE</span>
                                                                                <ul class="stars pull-right">
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                    <li <?php
                                                                                    if ($ratings == 'zero' || $ratings == 'one' || $ratings == 'two' || $ratings == 'three' || $ratings == 'four') {
                                                                                        echo 'class="no-rate"';
                                                                                    } else {
                                                                                        
                                                                                    }
                                                                                    ?>><i class="fa fa-star"></i></li>
                                                                                </ul>
                                                                            </div>

                                                                            <!--======= ITEM Details =========--> 
                                                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                                            <hr>
                                                                            <p><?php echo driveme_portfolio_excerpt($theme_option['courses_excerpt']); ?></p>
                                                                            <a href="<?php the_permalink(); ?>" class="btn"><?php echo esc_attr($theme_option['courses_apply']) ?></a> </div>
                                                                    </div>
                                                                </li>
                                                            <?php } ?>
                                                        <?php endwhile; ?>

                                                    </ul>
                                                </div>
                                            </div>

                                            <!--======= LOAD MORE =========-->
                                            <div class="text-center"> <a href="<?php echo esc_url($link); ?>" class="btn"><?php echo wp_specialchars_decode($text); ?></a> </div>
                                        </div>
                                    </div>
                                </section>


                                <?php
                                return ob_get_clean();
                            }

//map
                            add_shortcode('map', 'map_func');

                            function map_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'address' => '',
                                    'image' => '',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                $images = wp_get_attachment_image_src($image, '');
                                ?> 
                                <section class="contact"> 

                                    <!--======= MAP =========-->
                                    <div id="map"></div>
                                </section>
                                <script type="text/javascript">
                                    (function ($) {
                                        "use strict"
                                        $(document).ready(function () {
                                            //set up markers 
                                            var myMarkers = {"markers": [
                                                    {"icon": "<?php echo esc_url($images['0']); ?>", "baloon_text": '<?php echo $address; ?>'}
                                                ]};
                                            //set up map options
                                            $("#map").mapmarker({
                                                zoom: 16,
                                                center: '<?php echo $address; ?>',
                                                markers: myMarkers
                                            });

                                        });
                                    })(jQuery);
                                </script>


                                <?php
                                return ob_get_clean();
                            }

//contactinfo
                            add_shortcode('contactinfo', 'contactinfo_func');

                            function contactinfo_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                    'content1' => '',
                                    'facebook' => '',
                                    'twitter' => '',
                                    'google' => '',
                                    'linkedin' => '',
                                    'skype' => '',
                                    'dribbble' => '',
                                    'behance' => '',
                                                ), $atts));
                                ob_start();
                                global $theme_option;
                                ?> 
                                <h3><?php echo wp_specialchars_decode($title); ?></h3>
                                <p class="margin-b-40"><?php echo wp_specialchars_decode($desc); ?></p>
                                <?php echo wp_specialchars_decode($content); ?>

                                <!--======= SOCIAL ICON =========-->
                                <ul class="social_icons">
                                    <?php if ($facebook != '') { ?>
                                        <li class="facebook"> <a href="<?php echo esc_url($facebook); ?>"><i class="fa fa-facebook"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($twitter != '') { ?>
                                        <li class="twitter"> <a href="<?php echo esc_url($twitter); ?>"><i class="fa fa-twitter"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($linkedin != '') { ?>
                                        <li class="linkedin"> <a href="<?php echo esc_url($linkedin); ?>"><i class="fa fa-linkedin"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($google != '') { ?>
                                        <li class="googleplus"> <a href="<?php echo esc_url($google); ?>"><i class="fa fa-google-plus"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($dribbble != '') { ?>
                                        <li class="dribbble"> <a href="<?php echo esc_url($dribbble); ?>"><i class="fa fa-dribbble"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($skype != '') { ?>
                                        <li class="skype"> <a href="<?php echo esc_url($skype); ?>"><i class="fa fa-skype"></i> </a></li>
                                    <?php } ?>
                                    <?php if ($behance != '') { ?>
                                        <li class="behance"> <a href="<?php echo esc_url($behance); ?>"><i class="fa fa-behance"></i> </a></li>
                                    <?php } ?>
                                </ul>


                                <?php
                                return ob_get_clean();
                            }

//Tab
                            add_shortcode('tab', 'tab_func');

                            function tab_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title1' => '',
                                    'text1' => '',
                                    'posttype1' => '',
                                    'number1' => '',
                                    'orderpost1' => '',
                                    'orderby1' => '',
                                    'title2' => '',
                                    'text2' => '',
                                    'posttype2' => '',
                                    'number2' => '',
                                    'orderpost2' => '',
                                    'orderby2' => '',
                                    'title3' => '',
                                    'text3' => '',
                                    'posttype3' => '',
                                    'number3' => '',
                                    'orderpost3' => '',
                                    'orderby3' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <ul class="nav nav-tabs" id="myTab">
                                    <?php if ($posttype1 == 'events') { ?>
                                        <li class="active"><a href="#feature-news1" data-toggle="tab"><?php echo esc_attr($title1); ?></a></li>
                                    <?php } elseif ($posttype1 == 'players') { ?>
                                        <li class="active"><a href="#players-staff1" data-toggle="tab"><?php echo esc_attr($title1); ?></a></li>
                                    <?php } elseif ($posttype1 == 'teams') { ?>
                                        <li class="active"><a href="#club-news1" data-toggle="tab"><?php echo esc_attr($title1); ?></a></li>
                                    <?php } ?>

                                    <?php if ($posttype2 == 'events') { ?>
                                        <li><a href="#feature-news2" data-toggle="tab"><?php echo esc_attr($title2); ?></a></li>
                                    <?php } elseif ($posttype2 == 'players') { ?>
                                        <li><a href="#players-staff2" data-toggle="tab"><?php echo esc_attr($title2); ?></a></li>
                                    <?php } elseif ($posttype2 == 'teams') { ?>
                                        <li><a href="#club-news2" data-toggle="tab"><?php echo esc_attr($title2); ?></a></li>
                                    <?php } ?>

                                    <?php if ($posttype3 == 'events') { ?>
                                        <li><a href="#feature-news3" data-toggle="tab"><?php echo esc_attr($title3); ?></a></li>
                                    <?php } elseif ($posttype3 == 'players') { ?>
                                        <li><a href="#players-staff3" data-toggle="tab"><?php echo esc_attr($title3); ?></a></li>
                                    <?php } elseif ($posttype3 == 'teams') { ?>
                                        <li><a href="#club-news3" data-toggle="tab"><?php echo esc_attr($title3); ?></a></li>
                                    <?php } ?>

                                </ul>
                                <!-- End Nav Tabs -->

                                <!-- Content Tabs -->
                                <div class="tab-content">
                                    <!-- Tab One - Feature News -->
                                    <?php if ($posttype1 == 'events') { ?>
                                        <div class="tab-pane active" id="feature-news1">
                                            <!-- blog post-->  
                                            <ul id="events-carousel" class="events-carousel padding-top">
                                                <!-- Item blog post -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'events',
                                                    'posts_per_page' => $number1,
                                                    'order' => $orderpost1,
                                                    'orderby' => $orderby1,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();
                                                    $cates = get_the_terms(get_the_ID(), 'sample');
                                                    $cate_name = '';
                                                    $cate_slug = '';
                                                    foreach ((array) $cates as $cate) {
                                                        if (count($cates) > 0) {
                                                            $cate_name .= $cate->name . ' ';
                                                            $cate_slug .= $cate->slug . ' ';
                                                        }
                                                    }
                                                    $i++;
                                                    ?>

                                                    <li>
                                                        <div class="header-post">
                                                            <div class="date">
                                                                <span><?php the_time('j /M'); ?></span>
                                                                <?php the_time('Y'); ?>
                                                            </div>
                                                            <a href="<?php the_permalink(); ?>"><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt=""></a>
                                                            <div class="meta-tag">
                                                                <ul>
                                                                    <li><i class="fa fa-user"></i><?php the_author_posts_link(); ?></li>
                                                                    <li><i class="fa fa-folder-open"></i><a href="<?php the_permalink(); ?>"><?php echo esc_attr($cate_name); ?></a></li>
                                                                    <li class="text-right"><i class="fa fa-comment"></i><?php comments_number(esc_html__('0', 'sportcup'), esc_html__('1', 'sportcup'), esc_html__('%', 'sportcup')); ?></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="info-post">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <p><?php echo esc_attr(sportcup_excerpt($redux_demo['events_excerpt'])); ?></p>
                                                        </div>
                                                    </li>
                                                    <!-- End Item blog post -->
                                                <?php endwhile; ?>
                                                <!-- Item blog post -->  

                                            </ul>
                                            <!-- End blog post-->  
                                        </div>
                                        <!-- Tab One - Feature News -->
                                    <?php } elseif ($posttype1 == 'players') { ?>
                                        <!-- Tab Two - Players Staff -->
                                        <div class="tab-pane" id="players-staff1">
                                            <h3><?php echo esc_attr($text1); ?></h3>
                                            <!-- Item Players-->  
                                            <ul id="players-carousel" class="players ">
                                                <!-- Item Player -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'players',
                                                    'posts_per_page' => $number1,
                                                    'order' => $orderpost1,
                                                    'orderby' => $orderby1,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <li class="item-player">
                                                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                        <div class="info-player">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <h5><span><?php echo esc_attr(get_post_meta(get_the_ID(), '_cmb_players_job', true)); ?></span></h5>
                                                            <div class="overlay-player">
                                                                <p><?php echo esc_attr(sportcup_excerpt($redux_demo['players_excerpt'])); ?></p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <!-- End Player post -->
                                                <?php endwhile; ?>
                                                <!-- Item Player -->  

                                            </ul>
                                            <!-- End Item Players-->  
                                        </div>
                                        <!-- Tab Two - Players Staff -->
                                    <?php }elseif ($posttype1 == 'teams') { ?>
                                        <!-- Tab Theree - Club Teams -->
                                        <div class="tab-pane" id="club-news1">
                                            <h3><?php echo esc_attr($text1); ?></h3>
                                            <!-- Clubs Carousel-->  
                                            <ul id="clubs-carousel" class="clubs-teams">
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'team',
                                                    'posts_per_page' => $number1,
                                                    'order' => $orderpost1,
                                                    'orderby' => $orderby1,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <!-- Item carousel club -->  
                                                    <?php if ($i % 4 == '1') { ?>
                                                        <li class="row">
                                                        <?php } ?>
                                                        <!-- Item clubs --> 
                                                        <div class="col-sx-12 col-sm-6 col-md-6">
                                                            <div class="item-clubs">
                                                                <div class="img-clubs">
                                                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                                </div>
                                                                <div class="info-clubs">
                                                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                                    <p><?php echo esc_attr(sportcup_excerpt($redux_demo['team_excerpt'])); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End Item clubs --> 
                                                        <?php if ($i % 4 == '0') { ?>
                                                        </li>
                                                    <?php } ?>  
                                                <?php endwhile; ?>
                                                <!-- Item clubs --> 

                                            </ul>
                                            <!-- End Clubs Carousel-->  
                                        </div>
                                        <!-- Tab Theree - Club Teams -->
                                    <?php } ?>



                                    <?php if ($posttype2 == 'events') { ?>
                                        <div class="tab-pane active" id="feature-news2">
                                            <!-- blog post-->  
                                            <ul id="events-carousel" class="events-carousel padding-top">
                                                <!-- Item blog post -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'events',
                                                    'posts_per_page' => $number2,
                                                    'order' => $orderpost2,
                                                    'orderby' => $orderby2,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();
                                                    $cates = get_the_terms(get_the_ID(), 'sample');
                                                    $cate_name = '';
                                                    $cate_slug = '';
                                                    foreach ((array) $cates as $cate) {
                                                        if (count($cates) > 0) {
                                                            $cate_name .= $cate->name . ' ';
                                                            $cate_slug .= $cate->slug . ' ';
                                                        }
                                                    }
                                                    $i++;
                                                    ?>

                                                    <li>
                                                        <div class="header-post">
                                                            <div class="date">
                                                                <span><?php the_time('j /M'); ?></span>
                                                                <?php the_time('Y'); ?>
                                                            </div>
                                                            <a href="<?php the_permalink(); ?>"><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt=""></a>
                                                            <div class="meta-tag">
                                                                <ul>
                                                                    <li><i class="fa fa-user"></i><?php the_author_posts_link(); ?></li>
                                                                    <li><i class="fa fa-folder-open"></i><a href="<?php the_permalink(); ?>"><?php echo esc_attr($cate_name); ?></a></li>
                                                                    <li class="text-right"><i class="fa fa-comment"></i><?php comments_number(esc_html__('0', 'sportcup'), esc_html__('1', 'sportcup'), esc_html__('%', 'sportcup')); ?></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="info-post">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <p><?php echo esc_attr(sportcup_excerpt($redux_demo['events_excerpt'])); ?></p>
                                                        </div>
                                                    </li>
                                                    <!-- End Item blog post -->
                                                <?php endwhile; ?>
                                                <!-- Item blog post -->  

                                            </ul>
                                            <!-- End blog post-->  
                                        </div>
                                        <!-- Tab One - Feature News -->
                                    <?php } elseif ($posttype2 == 'players') { ?>
                                        <!-- Tab Two - Players Staff -->
                                        <div class="tab-pane" id="players-staff2">
                                            <h3><?php echo esc_attr($text2); ?></h3>
                                            <!-- Item Players-->  
                                            <ul id="players-carousel" class="players ">
                                                <!-- Item Player -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'players',
                                                    'posts_per_page' => $number2,
                                                    'order' => $orderpost2,
                                                    'orderby' => $orderby2,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <li class="item-player">
                                                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                        <div class="info-player">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <h5><span><?php echo esc_attr(get_post_meta(get_the_ID(), '_cmb_players_job', true)); ?></span></h5>
                                                            <div class="overlay-player">
                                                                <p><?php echo esc_attr(sportcup_excerpt($redux_demo['players_excerpt'])); ?></p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <!-- End Player post -->
                                                <?php endwhile; ?>
                                                <!-- Item Player -->  

                                            </ul>
                                            <!-- End Item Players-->  
                                        </div>
                                        <!-- Tab Two - Players Staff -->
                                    <?php }elseif ($posttype2 == 'teams') { ?>
                                        <!-- Tab Theree - Club Teams -->
                                        <div class="tab-pane" id="club-news2">
                                            <h3><?php echo esc_attr($text2); ?></h3>
                                            <!-- Clubs Carousel-->  
                                            <ul id="clubs-carousel" class="clubs-teams">
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'team',
                                                    'posts_per_page' => $number2,
                                                    'order' => $orderpost2,
                                                    'orderby' => $orderby2,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <!-- Item carousel club -->  
                                                    <?php if ($i % 4 == '1') { ?>
                                                        <li class="row">
                                                        <?php } ?>
                                                        <!-- Item clubs --> 
                                                        <div class="col-sx-12 col-sm-6 col-md-6">
                                                            <div class="item-clubs">
                                                                <div class="img-clubs">
                                                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                                </div>
                                                                <div class="info-clubs">
                                                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                                    <p><?php echo esc_attr(sportcup_excerpt($redux_demo['team_excerpt'])); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End Item clubs --> 
                                                        <?php if ($i % 4 == '0') { ?>
                                                        </li>
                                                    <?php } ?>  
                                                <?php endwhile; ?>
                                                <!-- Item clubs --> 

                                            </ul>
                                            <!-- End Clubs Carousel-->  
                                        </div>
                                        <!-- Tab Theree - Club Teams -->
                                    <?php } ?>





                                    <?php if ($posttype3 == 'events') { ?>
                                        <div class="tab-pane active" id="feature-news3">
                                            <!-- blog post-->  
                                            <ul id="events-carousel" class="events-carousel padding-top">
                                                <!-- Item blog post -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'events',
                                                    'posts_per_page' => $number3,
                                                    'order' => $orderpost3,
                                                    'orderby' => $orderby3,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();
                                                    $cates = get_the_terms(get_the_ID(), 'sample');
                                                    $cate_name = '';
                                                    $cate_slug = '';
                                                    foreach ((array) $cates as $cate) {
                                                        if (count($cates) > 0) {
                                                            $cate_name .= $cate->name . ' ';
                                                            $cate_slug .= $cate->slug . ' ';
                                                        }
                                                    }
                                                    $i++;
                                                    ?>

                                                    <li>
                                                        <div class="header-post">
                                                            <div class="date">
                                                                <span><?php the_time('j /M'); ?></span>
                                                                <?php the_time('Y'); ?>
                                                            </div>
                                                            <a href="<?php the_permalink(); ?>"><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt=""></a>
                                                            <div class="meta-tag">
                                                                <ul>
                                                                    <li><i class="fa fa-user"></i><?php the_author_posts_link(); ?></li>
                                                                    <li><i class="fa fa-folder-open"></i><a href="<?php the_permalink(); ?>"><?php echo esc_attr($cate_name); ?></a></li>
                                                                    <li class="text-right"><i class="fa fa-comment"></i><?php comments_number(esc_html__('0', 'sportcup'), esc_html__('1', 'sportcup'), esc_html__('%', 'sportcup')); ?></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="info-post">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <p><?php echo esc_attr(sportcup_excerpt($redux_demo['events_excerpt'])); ?></p>
                                                        </div>
                                                    </li>
                                                    <!-- End Item blog post -->
                                                <?php endwhile; ?>
                                                <!-- Item blog post -->  

                                            </ul>
                                            <!-- End blog post-->  
                                        </div>
                                        <!-- Tab One - Feature News -->
                                    <?php } elseif ($posttype3 == 'players') { ?>
                                        <!-- Tab Two - Players Staff -->
                                        <div class="tab-pane" id="players-staff3">
                                            <h3><?php echo esc_attr($text3); ?></h3>
                                            <!-- Item Players-->  
                                            <ul id="players-carousel" class="players ">
                                                <!-- Item Player -->  
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'players',
                                                    'posts_per_page' => $number3,
                                                    'order' => $orderpost3,
                                                    'orderby' => $orderby3,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <li class="item-player">
                                                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                        <div class="info-player">
                                                            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                            <h5><span><?php echo esc_attr(get_post_meta(get_the_ID(), '_cmb_players_job', true)); ?></span></h5>
                                                            <div class="overlay-player">
                                                                <p><?php echo esc_attr(sportcup_excerpt($redux_demo['players_excerpt'])); ?></p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <!-- End Player post -->
                                                <?php endwhile; ?>
                                                <!-- Item Player -->  

                                            </ul>
                                            <!-- End Item Players-->  
                                        </div>
                                        <!-- Tab Two - Players Staff -->
                                    <?php }elseif ($posttype3 == 'teams') { ?>
                                        <!-- Tab Theree - Club Teams -->
                                        <div class="tab-pane" id="club-news3">
                                            <h3><?php echo esc_attr($text3); ?></h3>
                                            <!-- Clubs Carousel-->  
                                            <ul id="clubs-carousel" class="clubs-teams">
                                                <?php
                                                $i = 0;
                                                $args = array(
                                                    'post_type' => 'team',
                                                    'posts_per_page' => $number3,
                                                    'order' => $orderpost3,
                                                    'orderby' => $orderby3,
                                                );
                                                $wp_query = new WP_Query($args);
                                                while ($wp_query->have_posts()) : $wp_query->the_post();

                                                    $i++;
                                                    ?>
                                                    <!-- Item carousel club -->  
                                                    <?php if ($i % 4 == '1') { ?>
                                                        <li class="row">
                                                        <?php } ?>
                                                        <!-- Item clubs --> 
                                                        <div class="col-sx-12 col-sm-6 col-md-6">
                                                            <div class="item-clubs">
                                                                <div class="img-clubs">
                                                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                                </div>
                                                                <div class="info-clubs">
                                                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                                    <p><?php echo esc_attr(sportcup_excerpt($redux_demo['team_excerpt'])); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End Item clubs --> 
                                                        <?php if ($i % 4 == '0') { ?>
                                                        </li>
                                                    <?php } ?>  
                                                <?php endwhile; ?>
                                                <!-- Item clubs --> 

                                            </ul>
                                            <!-- End Clubs Carousel-->  
                                        </div>
                                        <!-- Tab Theree - Club Teams -->
                                    <?php } ?>




                                </div>
                                <!-- Content Tabs -->


                                <?php
                                return ob_get_clean();
                            }

//Countdown
                            add_shortcode('countdown', 'countdown_func');

                            function countdown_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                    'date' => '',
                                    'calendar' => '',
                                    'clock' => '',
                                    'content1' => '',
                                    'text' => '',
                                    'link' => '',
                                    'icon' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <aside>
                                    <div class="title-color text-center">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>

                                    <div class="content-counter content-counter-home">
                                        <p class="text-center"> 
                                            <i class="fa fa-clock-o"></i> 
                                            <?php echo esc_attr($desc); ?>
                                        </p>
                                        <div id="event-one" class="counter"></div>
                                        <ul class="post-options">
                                            <li><i class="fa fa-calendar"></i><?php echo esc_attr($calendar); ?></li>
                                            <li><i class="fa fa-clock-o"></i><?php echo esc_attr($clock); ?></li> 
                                        </ul>
                                        <p><?php echo esc_attr($content1); ?></p>
                                        <a class="btn btn-primary" href="<?php echo esc_url($link); ?>">
                                            <?php echo esc_attr($text); ?>
                                            <i class="fa <?php echo esc_attr($icon); ?>"></i>
                                        </a>
                                    </div>
                                </aside>


                                <script type="text/javascript">
                                    (function ($) {
                                        "use strict"
                                        $(document).ready(function () {

                                            $('#event-one').countdown('<?php echo esc_attr($date); ?>', function (event) {
                                                var $this = $(this).html(event.strftime(''
                                                        + '<span>%D <br> <small>days</small></span>  '
                                                        + '<span>%H <br> <small>hr</small> </span>  '
                                                        + '<span>%M <br> <small>min</small> </span>  '
                                                        + '<span>%S <br> <small>sec</small></span> '));
                                            });


                                        });
                                    })(jQuery);
                                </script>


                                <?php
                                return ob_get_clean();
                            }

//News
                            add_shortcode('news', 'news_func');

                            function news_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'number' => '',
                                    'orderpost' => '',
                                    'orderby' => '',
                                                ), $atts));
                                ob_start();
                                ?>  

                                <!-- Recent Post -->
                                <div class="panel-box">

                                    <div class="titles">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>
                                    <?php
                                    global $redux_demo;
                                    $args = array(
                                        'post_type' => 'post',
                                        'posts_per_page' => $number,
                                        'order' => $orderpost,
                                        'orderby' => $orderby,
                                    );
                                    $wp_query = new WP_Query($args);
                                    while ($wp_query->have_posts()) : $wp_query->the_post();
                                        ?>
                                        <!-- Post Item -->
                                        <div class="post-item">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="img-hover">
                                                        <img src="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" alt="" class="img-responsive">
                                                        <div class="overlay"><a href="<?php the_permalink(); ?>">+</a></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                    <p class="data-info"><?php the_time('j M, Y'); ?>  / <i class="fa fa-comments"></i><?php comments_number(esc_html__('0', 'sportcup'), esc_html__('1', 'sportcup'), esc_html__('%', 'sportcup')); ?></p>
                                                    <p><?php echo esc_attr(sportcup_excerpt($redux_demo['blog_excerpt'])); ?> <br/><a href="<?php the_permalink(); ?>"><?php echo esc_attr($redux_demo['read_more']); ?></a></p>                                            
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Post Item -->
                                    <?php endwhile; ?>
                                    <!-- Post Item -->

                                </div>  
                                <!-- End Recent Post --> 




                                <?php
                                return ob_get_clean();
                            }

//Experts
                            add_shortcode('experts', 'experts_func');

                            function experts_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'number' => '',
                                    'orderpost' => '',
                                    'orderby' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <!-- Experts -->
                                <div class="panel-box">                            
                                    <div class="titles">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>     

                                    <div class="row">
                                        <?php
                                        $args = array(
                                            'post_type' => 'experts',
                                            'posts_per_page' => $number,
                                            'order' => $orderpost,
                                            'orderby' => $orderby,
                                        );
                                        $wp_query = new WP_Query($args);
                                        while ($wp_query->have_posts()) : $wp_query->the_post();
                                            ?>
                                            <div class="col-xs-6 col-sm-3 col-md-4 col-lg-3">
                                                <div class="box-info">
                                                    <img src="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" alt="" class="img-responsive">
                                                    <h5 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                                    <p class="date-box"><?php the_time('j M, Y'); ?></p>
                                                </div>
                                            </div> 
                                        <?php endwhile; ?>
                                    </div>                          
                                </div>  
                                <!-- End Experts --> 


                                <?php
                                return ob_get_clean();
                            }

//Locations
                            add_shortcode('locations', 'locations_func');

                            function locations_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'number' => '',
                                    'orderpost' => '',
                                    'orderby' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <div class="panel-box">

                                    <div class="titles">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>
                                    <!-- Locations Carousel --> 
                                    <ul class="single-carousel"> 
                                        <?php
                                        $args = array(
                                            'post_type' => 'locations',
                                            'posts_per_page' => $number,
                                            'order' => $orderpost,
                                            'orderby' => $orderby,
                                        );
                                        $wp_query = new WP_Query($args);
                                        while ($wp_query->have_posts()) : $wp_query->the_post();
                                            ?>   
                                            <li>
                                                <img src="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" alt="" class="img-responsive">
                                                <div class="info-single-carousel">
                                                    <h4><?php the_title(); ?></h4>
                                                    <?php the_content(); ?>
                                                </div>
                                            </li>
                                        <?php endwhile; ?>

                                    </ul>
                                    <!-- Locations Carousel -->                                
                                </div>  
                                <!-- End Locations -->  
                                <?php
                                return ob_get_clean();
                            }

//Text
                            add_shortcode('text', 'text_func');

                            function text_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <div class="panel-box">
                                    <div class="titles">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p><?php echo esc_attr($desc); ?></p>
                                        </div>
                                    </div>
                                </div>  



                                <?php
                                return ob_get_clean();
                            }

//Match
                            add_shortcode('match', 'match_func');

                            function match_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc' => '',
                                    'type' => '',
                                    'league' => '',
                                    'time' => '',
                                    'team1' => '',
                                    'logo1' => '',
                                    'team2' => '',
                                    'logo2' => '',
                                                ), $atts));
                                ob_start();
                                $logo1s = wp_get_attachment_image_src($logo1, '');
                                $logo2s = wp_get_attachment_image_src($logo2, '');
                                ?> 
                                <?php if ($type == 'start') { ?> 
                                    <div class="panel-box">
                                        <div class="titles">
                                            <h4><i class="fa fa-calendar"></i><?php echo esc_attr($title); ?></h4>
                                        </div>
                                        <!-- List Diary --> 
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p><?php echo esc_attr($desc); ?></p>
                                                <ul class="list-diary">
                                                    <!-- Item List Diary --> 
                                                <?php } ?>
                                                <li>
                                                    <h5><?php echo esc_attr($league); ?> <span><?php echo esc_attr($time); ?></span></h5>
                                                    <ul class="club-logo">
                                                        <li>
                                                            <img src="<?php echo esc_url($logo1s[0]); ?>" alt="">
                                                            <h6><?php echo esc_attr($team1); ?></h6>
                                                        </li>
                                                        <li>
                                                            <img src="<?php echo esc_url($logo2s[0]); ?>" alt="">
                                                            <h6><?php echo esc_attr($team2); ?></h6>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <!-- End Item List Diary --> 
                                                <?php if ($type == 'end') { ?> 
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- End List Diary -->                                
                                    </div>  
                                    <!-- End Diary -->
                                <?php } ?>

                                <?php
                                return ob_get_clean();
                            }

//Image
                            add_shortcode('image', 'image_func');

                            function image_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'link' => '',
                                    'image' => '',
                                                ), $atts));
                                ob_start();
                                $images = wp_get_attachment_image_src($image, '');
                                ?> 
                                <div class="panel-box">
                                    <a href="<?php echo esc_url($link); ?>" target="_blank">
                                        <img src="<?php echo esc_url($images[0]); ?>" class="img-responsive" alt="">
                                    </a>
                                </div> 


                                <?php
                                return ob_get_clean();
                            }

//Players
                            add_shortcode('players', 'players_func');

                            function players_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'number' => '',
                                    'orderpost' => '',
                                    'orderby' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <!-- content Players --> 
                                <div class="col-md-12">                     
                                    <!-- Panel Box -->
                                    <div class="panel-box">
                                        <div class="titles">
                                            <h4><i class="fa fa-group"></i><?php echo esc_attr($title); ?></h4>
                                        </div>
                                        <!-- Players --> 
                                        <div class="row">
                                            <div class="col-md-12">
                                                <!-- Item Players-->  
                                                <ul id="players-carousel" class="players">
                                                    <!-- Item Player --> 
                                                    <?php
                                                    $args = array(
                                                        'post_type' => 'players',
                                                        'posts_per_page' => $number,
                                                        'order' => $orderpost,
                                                        'orderby' => $orderby,
                                                    );
                                                    $wp_query = new WP_Query($args);
                                                    while ($wp_query->have_posts()) : $wp_query->the_post();
                                                        ?>    
                                                        <li class="item-player">
                                                            <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id()); ?>" alt="" class="img-responsive">
                                                            <div class="info-player">
                                                                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                                <h5><span><?php echo esc_attr(get_post_meta(get_the_ID(), '_cmb_players_job', true)); ?></span></h5>
                                                                <div class="overlay-player">
                                                                    <p><?php echo esc_attr(sportcup_excerpt($redux_demo['players_excerpt'])); ?></p>
                                                                </div>
                                                            </div>
                                                        </li>

                                                    <?php endwhile; ?>
                                                    <!-- Item Player -->  

                                                </ul>
                                                <!-- End Item Players-->  
                                            </div>
                                        </div>
                                        <!-- End Players -->                                
                                    </div>  
                                    <!-- End Panel Box --> 
                                </div>
                                <!-- End Players -->


                                <?php
                                return ob_get_clean();
                            }

//Progress
                            add_shortcode('progress', 'progress_func');

                            function progress_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'icon' => '',
                                    'text' => '',
                                    'type' => '',
                                    'percent' => '',
                                    'color' => '',
                                                ), $atts));
                                ob_start();
                                ?> 
                                <?php if ($type == 'start') { ?>
                                    <div class="panel-box">
                                        <div class="titles">
                                            <h4><i class="fa </i><?php echo esc_attr($icon); ?>"></i></i><?php echo esc_attr($title); ?></h4>
                                        </div>
                                        <!-- Skins --> 
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="pro_bar">

                                                <?php } ?>
                                                <h5 class="nocaps"></i><?php echo esc_attr($text); ?></h5>
                                                <div id="progress_bar" class="ui-progress-bar ui-container">
                                                    <div class="ui-progress <?php echo esc_attr($color); ?>" style="width:<?php echo esc_attr($percent); ?>%; ">
                                                        <span class="ui-label"><b class="value"></i><?php echo esc_attr($percent); ?>%</b></span>
                                                    </div>
                                                </div><!-- end section -->
                                                <?php if ($type != 'end') { ?> 
                                                    <br>
                                                <?php } ?>

                                                <?php if ($type == 'end') { ?> 
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Skins --> 
                                    </div>
                                <?php } ?>



                                <?php
                                return ob_get_clean();
                            }

//accrodation
                            add_shortcode('accrodation', 'accrodation_func');

                            function accrodation_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'icon' => '',
                                    'text' => '',
                                    'desc' => '',
                                    'type' => '',
                                    'active' => '',
                                                ), $atts));
                                ob_start();
                                ?> 
                                <?php if ($type == 'start') { ?>
                                    <div class="panel-box">
                                        <div class="titles">
                                            <h4><i class="fa <?php echo esc_attr($icon); ?>"></i><?php echo esc_attr($title); ?></h4>
                                        </div>
                                        <!-- Skins --> 
                                        <div class="row">
                                            <div class="accrodation">
                                            <?php } ?>
                                            <!-- section 1 -->
                                            <span class="acc-trigger <?php
                                            if ($active == 'yes') {
                                                echo 'active';
                                            }
                                            ?>"><a href="#"><?php echo esc_attr($text); ?></a></span>
                                            <div class="acc-container" style="display: <?php
                                            if ($active == 'no') {
                                                echo 'none';
                                            } elseif ($active == 'yes') {
                                                echo 'block';
                                            }
                                            ?>;">
                                                <div class="content">
                                                    <?php echo esc_attr($desc); ?>
                                                </div>
                                            </div>


                                            <?php if ($type == 'end') { ?> 
                                            </div>
                                        </div>
                                        <!-- End Skins --> 
                                    </div>  
                                    <!-- End Info-->
                                <?php } ?>




                                <?php
                                return ob_get_clean();
                            }

//about
                            add_shortcode('about', 'about_func');

                            function about_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'icon' => '',
                                    'image' => '',
                                    'text' => '',
                                    'desc' => '',
                                                ), $atts));
                                ob_start();
                                $images = wp_get_attachment_image_src($image, '');
                                ?>
                                <div class="col-md-12">
                                    <!-- Info -->
                                    <div class="panel-box">
                                        <div class="titles">
                                            <h4><i class="fa <?php echo esc_attr($icon); ?>"></i><?php echo esc_attr($title); ?></h4>
                                        </div>
                                        <!-- Info ABout --> 
                                        <div class="row">
                                            <div class="col-md-4">
                                                <!-- Mini SLide --> 
                                                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                                    <ol class="carousel-indicators">
                                                        <?php
                                                        if ($image != '') {
                                                            $image_ids = explode(",", $image);
                                                            $i = 0;
                                                            foreach ($image_ids AS $image_id) {
                                                                ?>
                                                                <li data-target="#carousel-example-generic" data-slide-to="<?php echo esc_attr($i); ?>" class="<?php
                                                                if ($i == 0) {
                                                                    echo 'active';
                                                                }
                                                                ?>"></li>
                                                                    <?php
                                                                    $i++;
                                                                }
                                                            }
                                                            ?>
                                                    </ol>
                                                    <div class="carousel-inner">
                                                        <?php
                                                        if ($image != '') {
                                                            $image_ids = explode(",", $image);
                                                            $i = 0;
                                                            foreach ($image_ids AS $image_id) {
                                                                $image_url = wp_get_attachment_image_src($image_id, '');
                                                                $i++;
                                                                ?>
                                                                <div class="item <?php
                                                                if ($i == '1') {
                                                                    echo 'active';
                                                                }
                                                                ?>">
                                                                    <img src="<?php echo esc_url($image_url[0]); ?>">
                                                                </div>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                                        <span class="glyphicon glyphicon-chevron-left"></span>
                                                    </a>
                                                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                                        <span class="glyphicon glyphicon-chevron-right"></span>
                                                    </a>
                                                </div>
                                                <!-- End Mini SLide --> 
                                            </div>
                                            <div class="col-md-8">
                                                <h4><?php echo esc_attr($text); ?></h4>
                                                <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>
                                            </div>
                                        </div>
                                        <!-- End Info ABout --> 
                                    </div>  
                                    <!-- End Info-->
                                </div>



                                <?php
                                return ob_get_clean();
                            }

//partner
                            add_shortcode('partner', 'partner_func');

                            function partner_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title_left' => '',
                                    'number' => '',
                                    'title_right' => '',
                                    'desc' => '',
                                    'text' => '',
                                    'type' => '',
                                    'link' => '',
                                    'image' => '',
                                                ), $atts));
                                ob_start();
                                $images = wp_get_attachment_image_src($image, '');
                                ?> 
                                <?php if ($type == 'start') { ?>
                                    <!-- Sponsors -->
                                    <div class="section-wide">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="text-center">
                                                        <h2><?php echo esc_attr($title_left); ?> <span class="text-resalt"><?php echo esc_attr($number); ?></span> <?php echo esc_attr($title_right); ?></h2>
                                                        <p><?php echo wp_specialchars_decode(esc_attr($desc)); ?></p>
                                                    </div>
                                                    <ul id="sponsors" class="tooltip-hover">

                                                    <?php } ?>
                                                    <li data-toggle="tooltip" title data-original-title="<?php echo esc_attr($text); ?>"> <a href="<?php echo esc_url($link); ?>"><img src="<?php echo esc_url($images[0]); ?>" alt="Image"></a></li>
                                                    <?php if ($type == 'end') { ?> 
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>  
                                    <!-- End Sponsors -->
                                <?php } ?>


                                <?php
                                return ob_get_clean();
                            }

//googlemap
                            add_shortcode('googlemap', 'googlemap_func');

                            function googlemap_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'lat' => '',
                                    'long' => '',
                                    'zoom' => '',
                                    'address1' => '',
                                    'desc1' => '',
                                    'address2' => '',
                                    'title1' => '',
                                    'title2' => '',
                                    'title3' => '',
                                    'desc2' => '',
                                    'address3' => '',
                                    'desc3' => '',
                                    'marker' => '',
                                                ), $atts));
                                ob_start();
                                $markers = wp_get_attachment_image_src($marker, '');
                                ?> 
                                <div id="map"></div>
                                <script type="text/javascript">
                                    (function ($) {
                                        "use strict"
                                        $(document).ready(function () {
                                            /*
                                             Map Settings
                                             Find the Latitude and Longitude of your address:  
                                             - http://universimmedia.pagesperso-orange.fr/geo/loc.htm  
                                             - http://www.findlatitudeandlongitude.com/find-address-from-latitude-and-longitude/
                                             */

                                            // Map Markers
                                            var mapMarkers = [{
                                                    address: "<?php echo esc_attr($address1); ?>",
                                                    html: "<strong><?php echo esc_attr($title1); ?></strong><br><?php echo esc_attr($desc1); ?><br><br><a href='#' onclick='mapCenterAt({latitude: 33.44792, longitude: -86.72963, zoom: 16}, event)'>[+] zoom here</a>",
                                                    icon: {
                                                        image: "<?php echo esc_url($markers[0]); ?>",
                                                        iconsize: [26, 46],
                                                        iconanchor: [12, 46]
                                                    }
                                                }, {
                                                    address: "<?php echo esc_attr($address2); ?>",
                                                    html: "<strong><?php echo esc_attr($title2); ?></strong><br><?php echo esc_attr($desc2); ?><br><br><a href='#' onclick='mapCenterAt({latitude: 36.80948, longitude: -119.77598, zoom: 16}, event)'>[+] zoom here</a>",
                                                    icon: {
                                                        image: "<?php echo esc_url($markers[0]); ?>",
                                                        iconsize: [26, 46],
                                                        iconanchor: [12, 46]
                                                    }
                                                }, {
                                                    address: "<?php echo esc_attr($address3); ?>",
                                                    html: "<strong><?php echo esc_attr($title3); ?></strong><br><?php echo esc_attr($desc3); ?><br><br><a href='#' onclick='mapCenterAt({latitude: 40.75198, longitude: -73.96978, zoom: 16}, event)'>[+] zoom here</a>",
                                                    icon: {
                                                        image: "<?php echo esc_url($markers[0]); ?>",
                                                        iconsize: [26, 46],
                                                        iconanchor: [12, 46]
                                                    }
                                                }];

                                            // Map Initial Location
                                            var initLatitude = <?php echo esc_attr($lat); ?>;
                                            var initLongitude = <?php echo esc_attr($long); ?>;

                                            // Map Extended Settings
                                            var mapSettings = {
                                                controls: {
                                                    panControl: true,
                                                    zoomControl: true,
                                                    mapTypeControl: true,
                                                    scaleControl: true,
                                                    streetViewControl: true,
                                                    overviewMapControl: true
                                                },
                                                scrollwheel: false,
                                                markers: mapMarkers,
                                                latitude: initLatitude,
                                                longitude: initLongitude,
                                                zoom: <?php echo esc_attr($zoom); ?>
                                            };

                                            $("#map").gMap(mapSettings);

                                        });
                                    })(jQuery);
                                </script>



                                <?php
                                return ob_get_clean();
                            }

//Info
                            add_shortcode('info', 'info_func');

                            function info_func($atts, $content = null) {
                                extract(shortcode_atts(array(
                                    'title' => '',
                                    'desc1' => '',
                                    'desc2' => '',
                                    'textaddress' => '',
                                    'address' => '',
                                    'textcity' => '',
                                    'city' => '',
                                    'textphone' => '',
                                    'phone' => '',
                                    'textemail1' => '',
                                    'email1' => '',
                                    'textemail2' => '',
                                    'email2' => '',
                                                ), $atts));
                                ob_start();
                                ?>  
                                <aside class="panel-box">
                                    <div class="titles">
                                        <h4><?php echo esc_attr($title); ?></h4>
                                    </div>
                                    <address>
                                        <strong><?php echo esc_attr($desc1); ?></strong><br>
                                        <i class="fa fa-map-marker"></i><strong><?php echo esc_attr($textaddress); ?> </strong> <?php echo esc_attr($address); ?><br>
                                        <i class="fa fa-plane"></i><strong><?php echo esc_attr($textcity); ?> </strong><?php echo esc_attr($city); ?><br>
                                        <i class="fa fa-phone"></i> <abbr title="Phone"><?php echo esc_attr($textphone); ?></abbr> <?php echo esc_attr($phone); ?>
                                    </address>
                                </aside>

                                <aside class="panel-box">
                                    <div class="titles">
                                        <h4><?php echo esc_attr($desc2); ?></h4>
                                    </div>
                                    <address>
                                        <i class="fa fa-envelope"></i><strong><?php echo esc_attr($textemail1); ?></strong><a href="mailto:<?php echo esc_attr($email1); ?>"> <?php echo esc_attr($email1); ?></a><br>
                                        <i class="fa fa-envelope"></i><strong><?php echo esc_attr($textemail2); ?></strong><a href="mailto:<?php echo esc_attr($email2); ?>"> <?php echo esc_attr($email2); ?></a>
                                    </address>
                                </aside>


                                <?php
                                return ob_get_clean();
                            }

                            /*------------------------------------------------------------------------------------------------------------------*/
/*  pricing table
/*------------------------------------------------------------------------------------------------------------------*/ 


